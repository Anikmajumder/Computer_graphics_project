#include<windows.h>
#include<cstdio>
#include<GL/gl.h>
#include<GL/glut.h>
#include<math.h>
#include<bits/stdc++.h>

# define PI 3.14159265358979323846

void drawQuad(GLfloat , GLfloat , GLfloat , GLfloat , GLfloat , GLfloat , GLfloat , GLfloat);
void drawQuadGradient(GLfloat , GLfloat , GLfloat , GLfloat , GLfloat , GLfloat , GLfloat , GLfloat);
void drawLine(GLfloat , GLfloat , GLfloat , GLfloat);
void drawTriangle(GLfloat , GLfloat , GLfloat , GLfloat , GLfloat , GLfloat);
void drawHalfCircle(GLfloat,GLfloat,GLfloat);
void drawCircle(GLfloat,GLfloat,GLfloat);
void drawElipse(GLfloat x,GLfloat y,GLfloat radius,GLfloat xx,GLfloat yy,int start);

GLfloat positionc=0.0f;
GLfloat t = 0.0f;


void sound();
void Day();
void Night();
void dayRain();
void nightDispaly(int x);
void dayDisplay(int x);
void dayRainDisplay(int x);
void nightRain();
void nightRainDispaly(int x);

GLfloat positionSun=0.0f;
GLfloat speedSun=0.02f;
void updateSun(int value)
{
    if(positionSun > .80)
        positionSun =-.2f;
    positionSun += speedSun;
    glutPostRedisplay();
    glutTimerFunc(100, updateSun, 0);
}

GLfloat positionMoon=0.0f;
GLfloat speedMoon=0.02f;
void updateMoon(int value)
{
    if(positionMoon <- .80)
        positionMoon =.2f;
    positionMoon -= speedMoon;
    glutPostRedisplay();
    glutTimerFunc(100, updateMoon, 0);
}


GLfloat snowPosition = 0.0f;
GLfloat snowSpeed = 0.05f;

void update11(int value)
{

       if(snowPosition < -1.5)
       {
         snowPosition = 2.0f;
       }

       if(snowPosition>2.0)
       {
          snowPosition=-1.5;
       }
       snowPosition -= snowSpeed;
       glutPostRedisplay();
       glutTimerFunc(40, update11, 0);
}
void snow()
{
    glPushMatrix();
    glTranslatef(-snowPosition,snowPosition, 0.0f);
    glColor3ub(255,255,255);
    drawCircle(0,0,0.025);
    drawCircle(-0.6,0.7,0.025);
    drawCircle(-0,0.9,0.025);
    drawCircle(-0.86,0.7,0.025);
    drawCircle(-0.65,0.87,0.025);
    drawCircle(-0.57,0.34,0.025);
    drawCircle(0,0,0.025);
    drawCircle(0.54,0.52,0.025);
    drawCircle(0.67,0.67,0.025);
    drawCircle(0.82,0.35,0.025);
    drawCircle(0.38,0.2,0.025);
    drawCircle(0.9,0.6,0.025);
    drawCircle(0.2,0.5,0.025);
    drawCircle(-0.32,0.5,0.025);
    drawCircle(-0.65,0.25,0.025);
    drawCircle(-0.7,0.3,0.025);

    glTranslatef(snowPosition,snowPosition, 0.0f);
    glColor3ub(255,255,255);
    glTranslatef(-0.2,1,0);
    drawCircle(0,0,0.025);
    drawCircle(-0.6,0.7,0.025);
    drawCircle(-0,0.9,0.025);
    drawCircle(-0.86,0.7,0.025);
    drawCircle(-0.65,0.87,0.025);
    drawCircle(-0.57,0.34,0.025);
    drawCircle(0,0,0.025);
    drawCircle(0.54,0.52,0.025);
    drawCircle(0.67,0.67,0.025);
    drawCircle(0.82,0.35,0.025);
    drawCircle(0.38,0.2,0.025);
    drawCircle(0.9,0.6,0.025);
    drawCircle(0.2,0.5,0.025);
    drawCircle(-0.32,0.5,0.025);
    drawCircle(-0.65,0.25,0.025);
    drawCircle(-0.7,0.3,0.025);


    glTranslatef(0.0f,snowPosition, 0.0f);
    glColor3ub(255,255,255);
    glTranslatef(0.2,0,0);
    drawCircle(0,0,0.025);
    drawCircle(-0.6,0.7,0.025);
    drawCircle(-0,0.9,0.025);
    drawCircle(-0.86,0.7,0.025);
    drawCircle(-0.65,0.87,0.025);
    drawCircle(-0.57,0.34,0.025);
    drawCircle(0,0,0.025);
    drawCircle(0.54,0.52,0.025);
    drawCircle(0.67,0.67,0.025);
    drawCircle(0.82,0.35,0.025);
    drawCircle(0.38,0.2,0.025);
    drawCircle(0.9,0.6,0.025);
    drawCircle(0.2,0.5,0.025);
    drawCircle(-0.32,0.5,0.025);
    drawCircle(-0.65,0.25,0.025);
    drawCircle(-0.7,0.3,0.025);

    glPopMatrix();
}

GLfloat positionBird=0.0f;
GLfloat speedBird=0.01f;
void updateBird(int value)
{
    if(positionBird > 1.0)
        positionBird =-1.0f;
    positionBird += speedBird;
    glutPostRedisplay();
    glutTimerFunc(100, updateBird, 0);
}

GLfloat positionCar=0.0f;
GLfloat speedCar=0.025;
void updateCar(int value)
{
    if(positionCar > 1.85)
        positionCar =-.30f;
    positionCar += speedCar;
    glutPostRedisplay();
    glutTimerFunc(100, updateCar, 0);
}

GLfloat positionCar2=0.0f;
GLfloat speedCar2=0.035;
void updateCar2(int value)
{
    if(positionCar2 < -1.85f)
        positionCar2 = .3f;
    positionCar2 -= speedCar2;
    glutPostRedisplay();
    glutTimerFunc(100, updateCar2, 0);
}


GLfloat positionRain= 0.0f;
GLfloat speedRain=- 0.01f;
void updateRain(int value)
{
    if(positionRain < -0.02f)
    {
        positionRain = 0.02f;
    }

    positionRain += speedRain;
    //glutPostRedisplay();
    glutTimerFunc(100, updateRain, 0);
}

GLfloat positionBoat=0.0f;
GLfloat speedBoat=- 0.01f;
void updateBoat(int value)
{
    if(positionBoat < -1.5f)
    {
        positionBoat = 1.0f;
    }

    positionBoat += speedBoat;
    //glutPostRedisplay();
    glutTimerFunc(100, updateBoat, 0);
}

GLfloat positionCloud1=0.0f;
GLfloat speedCloud1=0.003f;
void updateCloud1(int value)
{
    if(positionCloud1 < -1.5f)
    {
        positionCloud1 = 1.0f;
    }

    positionCloud1 -= speedCloud1;
    //glutPostRedisplay();
    glutTimerFunc(100, updateCloud1, 0);
}

GLfloat positionCloud2=0.0f;
GLfloat speedCloud2=0.01f;
void updateCloud2(int value)
{
    if(positionCloud2 < -1.25f)
    {
        positionCloud2 = 1.30f;
    }

    positionCloud2 -= speedCloud2;
    //glutPostRedisplay();
    glutTimerFunc(100, updateCloud2, 0);
}

GLfloat positionStandinfBoat=0.0f;
GLfloat speedStandingBoat=0.002f;
void updateStandingBoat(int value)
{
    if(positionStandinfBoat < -0.03)
    {
        positionStandinfBoat = 0.0f;
    }

    positionStandinfBoat -= speedStandingBoat;
    //glutPostRedisplay();
    glutTimerFunc(100, updateStandingBoat, 0);
}


void Sky()
{
        glBegin(GL_QUADS);
        glColor3ub (84, 153, 199);
        glVertex2f(1,1);
        glVertex2f(-1,1);
        glVertex2f(-1,-1);
        glVertex2f(1,-1);
        glEnd();
}
void NightSky()
{
        glBegin(GL_QUADS);
        glColor3ub (0, 19, 77);
        glVertex2f(1,1);
        glVertex2f(-1,1);
        glVertex2f(-1,-1);
        glVertex2f(1,-1);
        glEnd();
}

void Sun()
{

glTranslatef(-0.7,0.3,0);
glScalef(-0.5,0.5,0);
glBegin(GL_TRIANGLES);
        glColor3ub(255, 167, 38);
        glVertex2f(0.02,0.08);
        glVertex2f(0,0.18);
        glVertex2f(-0.02,0.08);
  glEnd();


glBegin(GL_TRIANGLES);
        glColor3ub(255, 167, 38);
        glVertex2f(0.18,0.0);
        glVertex2f(0.10,-0.02);
        glVertex2f(0.10,0.02);
  glEnd();

  glBegin(GL_TRIANGLES);
        glColor3ub(255, 167, 38);
        glVertex2f(0.08,0.04);
        glVertex2f(0.12,0.12);
        glVertex2f(0.04,0.08);
  glEnd();

 glBegin(GL_TRIANGLES);
        glColor3ub(255, 167, 38);
        glVertex2f(0.0,-0.18);
        glVertex2f(0.02,-0.10);
        glVertex2f(-0.02,-0.10);
  glEnd();

   glBegin(GL_TRIANGLES);
        glColor3ub(255, 167, 38);
        glVertex2f(0.08,-0.04);
        glVertex2f(0.12,-0.12);
        glVertex2f(0.04,-0.08);
  glEnd();

  glBegin(GL_TRIANGLES);
        glColor3ub(255, 167, 38);
        glVertex2f(-0.08,-0.04);
        glVertex2f(-0.04,-0.08);
        glVertex2f(-0.12,-0.12);
  glEnd();

   glBegin(GL_TRIANGLES);
        glColor3ub(255, 167, 38);
        glVertex2f(-0.08,0.04);
        glVertex2f(-0.04,0.08);
        glVertex2f(-0.12,0.12);
  glEnd();

   glBegin(GL_TRIANGLES);
        glColor3ub(255, 167, 38);
        glVertex2f(-0.10,0.02);
        glVertex2f(-0.18,0);
        glVertex2f(-0.10,-0.02);
  glEnd();


	int is;

	GLfloat xs=0.0f; GLfloat ys=0.0f; GLfloat radiuss =0.1f;
	glColor3ub(255, 87, 34);
	int triangleAmounts = 100; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePiss = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(xs, ys); // center of circle
		for(is = 0; is <= triangleAmounts;is++) {
			glVertex2f(
		            xs + (radiuss * cos(is *  twicePiss / triangleAmounts)),
			    ys + (radiuss * sin(is * twicePiss / triangleAmounts))
			);
		}

	glEnd();

	glLoadIdentity();
}

void Moon()
{
    glTranslatef(-0.7,0.8,0);
glScalef(-0.5,0.5,0);

	int in;

	GLfloat xn=0.0f; GLfloat yn=0.0f; GLfloat radiusn =0.1f;
	glColor3ub(255, 255, 255);
	int triangleAmountn = 100; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePin = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(xn, yn); // center of circle
		for(in = 0; in <= triangleAmountn;in++) {
			glVertex2f(
		            xn + (radiusn * cos(in *  twicePin / triangleAmountn)),
			    yn + (radiusn * sin(in * twicePin / triangleAmountn))
			);
		}

	glEnd();
	glLoadIdentity();


	glTranslatef(-0.7,0.8,0);
glScalef(-0.5,0.5,0);

	 int i;

	 GLfloat x=-0.1f;  GLfloat y=0.05f; GLfloat radius =0.1f;
	glColor3ub(0, 19, 77);
	 int triangleAmount = 100; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}

	glEnd();
	glLoadIdentity();

}

void Grass()
{
    ///Grass1
       glTranslatef(.0,0.8,0 );
       glScalef(1.0,1.5,0);
       glColor3ub(0,179,0);
       drawQuad(-1,-0.3, -1,-.6, 1,-.6, 1,-0.3);
       glLoadIdentity();
       ///Grass2
       glTranslatef(.0,0.42,0 );
       glScalef(1.0,1.5,0);
       glColor3ub(0,160,0);
       drawQuad(-1,-0.3, -1,-.6, 1,-.6, 1,-0.3);
       glLoadIdentity();
}
void Grass_Night()
{
    ///Grass1
       glTranslatef(.0,0.8,0 );
       glScalef(1.0,1.5,0);
       glColor3ub(0, 77, 0);
       drawQuad(-1,-0.3, -1,-.6, 1,-.6, 1,-0.3);
       glLoadIdentity();
       ///Grass2
       glTranslatef(.0,0.42,0 );
       glScalef(1.0,1.5,0);
       glColor3ub(0, 77, 0);
       drawQuad(-1,-0.3, -1,-.6, 1,-.6, 1,-0.3);
       glLoadIdentity();
}
void River()
{
    ///River
        glTranslatef(0,.55,0 );
        glScalef(1.0,.8,0);
        glColor3ub (118, 215, 196);
        drawQuad(-1,-0.3, -1.5,-.6, 1.5,-.6, 1.5,-0.3);
}
void River_Night()
{
    ///River
        glTranslatef(0,.55,0 );
        glScalef(1.0,.8,0);
        glColor3ub (0, 179, 179);
        drawQuad(-1,-0.3, -1.5,-.6, 1.5,-.6, 1.5,-0.3);
        glLoadIdentity();
}
void Boat()
{
    ///Boat_________---

        glTranslatef(-1.65,-.63,0);
    glScalef(2.5,4,0);
	glColor3ub (150, 129, 117);
    glBegin(GL_QUADS);
    glVertex2f(.350, .195);
    glVertex2f(.360, .183);
    glVertex2f(.410, .183);
    glVertex2f(.420, .195);
    glEnd();
    /////////////////boat roof
    glColor3ub (220, 118, 51);
    glBegin(GL_QUADS);
    glVertex2f(.370, .195);
    glVertex2f(.400, .195);
    glVertex2f(.400, .210);
    glVertex2f(.370, .210);
    glEnd();
    ////////////////////khuti and dori
    glColor3ub (46, 64, 83);
    glBegin(GL_LINES);
    glVertex2f(.340, .170);
    glVertex2f(.340, .210);
    glVertex2f(.340, .200);
    glVertex2f(.350,.195);
    glEnd();
    glLoadIdentity();
}
void National_Assembly_Night()
{
    ///National Assembly///

        glTranslatef(0.0,-.05,0 );
        glScalef(.65,1.2,0);

glColor3ub(166, 166, 166);drawQuad(0.2,0, 0.2,0.5, -0.2,0.5, -0.2,0);
///right side///
 glColor3ub(128, 128, 128);
    drawQuad(0.2,0.4,0.2,0.46, 0.26,0.5, 0.26,0.4 );
   glColor3ub(128, 128, 128);
    drawQuad( 0.26,0.5, 0.35,0.5,0.35,0.4,0.26,0.4 );
    glColor3ub(128, 128, 128);
    drawQuad(0.2,0, 0.4,0,0.4,0.48, 0.2,0.4);
glColor3ub(140, 140, 140);
   drawQuad(0.4,0.1, 0.4,0.48, 0.6,0.44, 0.6,0.1);
 glColor3ub(166, 166, 166);
    drawQuad(0.7,0.32, 0.9,0.32,0.9,-0.1,0.7,-0.1);
   glColor3ub(128, 128, 128);
   drawQuad(0.6,-0.1, 0.6,0.44, 0.8,0.41, 0.8,-0.1);
 glColor3ub(153, 77, 0);
    drawQuad(0.3,0, 0.4,0.1,0.78,0.1, 0.78,-0.1);
glColor3ub(255,255,255);
glColor3ub(255,255,255);
   drawQuad(0.3,0, 0.4,0.1, 0.42,0.1, 0.32,0);
   glColor3ub(255,255,255);
   drawQuad(0.48,0, 0.58,0.1, 0.6,0.1, 0.5,0);
glColor3ub(217, 217, 217);
   drawQuad(0.5,0, 0.9,-0.1, -0.9,-0.1, -0.5,0);
    glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.1);
        glVertex2f(0.2,0.1);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.3);
        glVertex2f(0.2,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.2);
        glVertex2f(0.2,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.4);
        glVertex2f(0.2,0.4);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.2,0.1);
        glVertex2f(0.4,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.2,0.3);
        glVertex2f(0.4,0.4);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.2,0.2);
        glVertex2f(0.4,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.4,0.2);
        glVertex2f(0.8,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.4,0.3);
        glVertex2f(0.8,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.4,0.4);
        glVertex2f(0.8,0.4);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.1,0);
        glVertex2f(0.1,0.5);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.1,0);
        glVertex2f(-0.1,0.5);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.3,0);
        glVertex2f(0.3,0.44);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.5,0.1);
        glVertex2f(0.5,0.46);
        glEnd();
         glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.7,0.1);
        glVertex2f(0.7,0.42);
        glEnd();
 glColor3ub(77, 77, 0);
   drawQuad(0.59,0.1, 0.61,0.1, 0.61,0.43, 0.59,0.44);
         glColor3ub(0, 0, 0);
    drawQuad(0.06,0, 0.06,0.4,-0.06,0.4, -0.06,0);
    glColor3ub(153, 153, 153);
    drawQuad( 0.06,0.4,-0.06,0.4,-0.06,0.48,0.06,0.48);
    glColor3ub(204, 255, 255);
    drawQuad( -0.06,0.48,0.06,0.48,0.06,0.5,-0.06,0.5);
     glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.1,0.02);
        glVertex2f(0.1,-0.06);
        glEnd();
 glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.1,0.02);
        glVertex2f(-0.1,-0.06);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.025,0.01);
        glVertex2f(-0.025,0.2);
        glEnd();
         glColor3ub(0, 153, 0);
    drawQuad(-0.025,0.2, 0.05,0.2,0.05,0.15, -0.025,0.15);
 int q;
    GLfloat a8=.01f; GLfloat b8=.176f; GLfloat radius8 =.01f;
	glColor3ub(255, 0, 0);
	int triangleAmount8 = 20;
	GLfloat twicePi8 = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a8, b8); // center of circle
		for(q= 0; q <= triangleAmount8;q++) {
			glVertex2f(
		            a8+ (radius8 * cos(q *  twicePi8 / triangleAmount8)),
			    b8 + (radius8 * sin(q * twicePi8 / triangleAmount8))
			);
		}
	glEnd();
	int u0;
    GLfloat a11=.3f; GLfloat b11=.1f; GLfloat radius11 =.05f;
	glColor3ub(51, 51, 0);
	int triangleAmount11 = 10;
	GLfloat twicePi11 = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a11, b11); // center of circle
		for(u0= 0; u0 <= triangleAmount11;u0++) {
			glVertex2f(
		            a11+ (radius11 * cos(u0 *  twicePi11 / triangleAmount11)),
			    b11 + (radius11 * sin(u0 * twicePi11 / triangleAmount11))
			);
		}
	glEnd();
	glBegin(GL_TRIANGLES);
        glColor3ub(51, 51, 0);
        glVertex2f(0.48,0.4);
        glVertex2f(0.52,0.2);
        glVertex2f(0.42,0.2);
  glEnd();
         glColor3ub(51, 51, 0);
drawQuad(0.52,0.1, 0.42,0.1,0.42,0.15,0.52,0.15);
	glBegin(GL_TRIANGLES);
        glColor3ub(51, 51, 0);
        glVertex2f(0.7,0.4);
        glVertex2f(0.65,0.2);
        glVertex2f(0.72,0.2);
  glEnd();
           glColor3ub(51, 51, 0);
drawQuad( 0.72,0.1,0.65,0.1,0.65,0.15,0.72,0.15);
///left side////
glColor3ub(128, 128, 128);
    drawQuad(-0.2,0.4,-0.2,0.46, -0.26,0.5,-0.26,0.4 );
glColor3ub(128, 128, 128);
    drawQuad( -0.26,0.5, -0.35,0.5,-0.35,0.4,-0.26,0.4 );
    glColor3ub(128, 128, 128);
    drawQuad(-0.2,0, -0.4,0,-0.4,0.48, -0.2,0.4);
glColor3ub(140, 140, 140);
   drawQuad(-0.4,0.1, -0.4,0.48, -0.6,0.44, -0.6,0.1);
    glColor3ub(166, 166, 166);
    drawQuad(-0.7,0.32, -0.9,0.32,-0.9,-0.1,-0.7,-0.1);
glColor3ub(128, 128, 128);
   drawQuad(-0.6,-0.1,- 0.6,0.44, -0.8,0.41, -0.8,-0.1);
glColor3ub(153, 77, 0);
    drawQuad(-0.3,0, -0.4,0.1,-0.78,0.1,- 0.78,-0.1);
glColor3ub(255,255,255);
   drawQuad(-0.3,0, -0.4,0.1, -0.42,0.1,- 0.32,0);
glColor3ub(255,255,255);
   drawQuad(-0.48,0, -0.58,0.1, -0.6,0.1, -0.5,0);
glColor3ub(217, 217, 217);
   drawQuad(0.5,0, 0.9,-0.1, -0.9,-0.1, -0.5,0);
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.1);
        glVertex2f(-0.4,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.3);
        glVertex2f(-0.4,0.4);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.2);
        glVertex2f(-0.4,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.4,0.2);
        glVertex2f(-0.8,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.4,0.3);
        glVertex2f(-0.8,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.4,0.4);
        glVertex2f(-0.8,0.4);
        glEnd();
         glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.7,0.1);
        glVertex2f(-0.7,0.42);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.3,0);
        glVertex2f(-0.3,0.44);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.5,0.1);
        glVertex2f(-0.5,0.46);
        glEnd();
glColor3ub(102, 68, 0);
    drawQuad(0.1,0.02, 0.1,-0.06,-0.1,-0.06, -0.1,0.02);
glColor3ub(77, 77, 0);
   drawQuad(-0.59,0.1, -0.61,0.1, -0.61,0.43, -0.59,0.44);
	int u1;
    GLfloat a111=-.3f; GLfloat b111=.1f; GLfloat radius111 =.05f;
	glColor3ub(51, 51, 0);
	int triangleAmount111 = 10; //# of triangles used to draw circle
	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi111 = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a111, b111); // center of circle
		for(u1= 0; u1 <= triangleAmount11;u1++) {
			glVertex2f(
		            a111+ (radius111 * cos(u1 *  twicePi11 / triangleAmount11)),
			    b111 + (radius111 * sin(u1 * twicePi11 / triangleAmount11))
			);
		}
	glEnd();
	glBegin(GL_TRIANGLES);
        glColor3ub(51, 51, 0);
        glVertex2f(-0.48,0.4);
        glVertex2f(-0.52,0.2);
        glVertex2f(-0.42,0.2);
  glEnd();
         glColor3ub(51, 51, 0);
drawQuad(-0.52,0.1, -0.42,0.1,-0.42,0.15,-0.52,0.15);
	glBegin(GL_TRIANGLES);
        glColor3ub(51, 51, 0);
        glVertex2f(-0.7,0.4);
        glVertex2f(-0.65,0.2);
        glVertex2f(-0.72,0.2);
  glEnd();
           glColor3ub(51, 51, 0);
drawQuad( -0.72,0.1,-0.65,0.1,-0.65,0.15,-0.72,0.15);

glColor3ub(128, 128, 128);
drawQuad(-0.7,-0.05, 0.7,-0.05, 0.9,-0.1,-0.9,-0.1);
glColor3ub(191, 191, 191);
drawQuad(-0.9,-0.1, 0.9,-0.1, 0.9,-0.13,-0.9,-0.13);
glColor3ub(128, 128, 128);
drawQuad(-0.9,-0.13, 0.9,-0.13, 0.93,-0.16,-0.93,-0.16);
glColor3ub(179, 179, 179);
drawQuad(-0.93,-0.16, 0.93,-0.16, 0.93,-0.19,-0.93,-0.19);
glLoadIdentity();

         ///END_OF________________-
}


void National_Assembly()
{
    glTranslatef(0.0,-.05,0 );
        glScalef(.65,1.2,0);

glColor3ub(204, 204, 204);drawQuad(0.2,0, 0.2,0.5, -0.2,0.5, -0.2,0);
///right side///
 glColor3ub(191, 191, 191);
    drawQuad(0.2,0.4,0.2,0.46, 0.26,0.5, 0.26,0.4 );
   glColor3ub(204, 204, 204);
    drawQuad( 0.26,0.5, 0.35,0.5,0.35,0.4,0.26,0.4 );
    glColor3ub(166, 166, 166);
    drawQuad(0.2,0, 0.4,0,0.4,0.48, 0.2,0.4);
glColor3ub(191, 191, 191);
   drawQuad(0.4,0.1, 0.4,0.48, 0.6,0.44, 0.6,0.1);
 glColor3ub(191, 191, 191);
    drawQuad(0.7,0.32, 0.9,0.32,0.9,-0.1,0.7,-0.1);
   glColor3ub(204, 204, 204);
   drawQuad(0.6,-0.1, 0.6,0.44, 0.8,0.41, 0.8,-0.1);
 glColor3ub(153, 77, 0);
    drawQuad(0.3,0, 0.4,0.1,0.78,0.1, 0.78,-0.1);
glColor3ub(255,255,255);
glColor3ub(255,255,255);
   drawQuad(0.3,0, 0.4,0.1, 0.42,0.1, 0.32,0);
   glColor3ub(255,255,255);
   drawQuad(0.48,0, 0.58,0.1, 0.6,0.1, 0.5,0);
glColor3ub(217, 217, 217);
   drawQuad(0.5,0, 0.9,-0.1, -0.9,-0.1, -0.5,0);
    glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.1);
        glVertex2f(0.2,0.1);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.3);
        glVertex2f(0.2,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.2);
        glVertex2f(0.2,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.4);
        glVertex2f(0.2,0.4);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.2,0.1);
        glVertex2f(0.4,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.2,0.3);
        glVertex2f(0.4,0.4);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.2,0.2);
        glVertex2f(0.4,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.4,0.2);
        glVertex2f(0.8,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.4,0.3);
        glVertex2f(0.8,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.4,0.4);
        glVertex2f(0.8,0.4);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.1,0);
        glVertex2f(0.1,0.5);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.1,0);
        glVertex2f(-0.1,0.5);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.3,0);
        glVertex2f(0.3,0.44);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.5,0.1);
        glVertex2f(0.5,0.46);
        glEnd();
         glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.7,0.1);
        glVertex2f(0.7,0.42);
        glEnd();
 glColor3ub(77, 77, 0);
   drawQuad(0.59,0.1, 0.61,0.1, 0.61,0.43, 0.59,0.44);
         glColor3ub(0, 0, 0);
    drawQuad(0.06,0, 0.06,0.4,-0.06,0.4, -0.06,0);
    glColor3ub(153, 153, 153);
    drawQuad( 0.06,0.4,-0.06,0.4,-0.06,0.48,0.06,0.48);
    glColor3ub(204, 255, 255);
    drawQuad( -0.06,0.48,0.06,0.48,0.06,0.5,-0.06,0.5);
     glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(0.1,0.02);
        glVertex2f(0.1,-0.06);
        glEnd();
 glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.1,0.02);
        glVertex2f(-0.1,-0.06);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.025,0.01);
        glVertex2f(-0.025,0.2);
        glEnd();
         glColor3ub(0, 153, 0);
    drawQuad(-0.025,0.2, 0.05,0.2,0.05,0.15, -0.025,0.15);
 int q;
    GLfloat a8=.01f; GLfloat b8=.176f; GLfloat radius8 =.01f;
	glColor3ub(255, 0, 0);
	int triangleAmount8 = 20;
	GLfloat twicePi8 = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a8, b8); // center of circle
		for(q= 0; q <= triangleAmount8;q++) {
			glVertex2f(
		            a8+ (radius8 * cos(q *  twicePi8 / triangleAmount8)),
			    b8 + (radius8 * sin(q * twicePi8 / triangleAmount8))
			);
		}
	glEnd();
	int u0;
    GLfloat a11=.3f; GLfloat b11=.1f; GLfloat radius11 =.05f;
	glColor3ub(51, 51, 0);
	int triangleAmount11 = 10;
	GLfloat twicePi11 = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a11, b11); // center of circle
		for(u0= 0; u0 <= triangleAmount11;u0++) {
			glVertex2f(
		            a11+ (radius11 * cos(u0 *  twicePi11 / triangleAmount11)),
			    b11 + (radius11 * sin(u0 * twicePi11 / triangleAmount11))
			);
		}
	glEnd();
	glBegin(GL_TRIANGLES);
        glColor3ub(51, 51, 0);
        glVertex2f(0.48,0.4);
        glVertex2f(0.52,0.2);
        glVertex2f(0.42,0.2);
  glEnd();
         glColor3ub(51, 51, 0);
drawQuad(0.52,0.1, 0.42,0.1,0.42,0.15,0.52,0.15);
	glBegin(GL_TRIANGLES);
        glColor3ub(51, 51, 0);
        glVertex2f(0.7,0.4);
        glVertex2f(0.65,0.2);
        glVertex2f(0.72,0.2);
  glEnd();
           glColor3ub(51, 51, 0);
drawQuad( 0.72,0.1,0.65,0.1,0.65,0.15,0.72,0.15);
///left side////
glColor3ub(191, 191, 191);
    drawQuad(-0.2,0.4,-0.2,0.46, -0.26,0.5,-0.26,0.4 );
glColor3ub(204, 204, 204);
    drawQuad( -0.26,0.5, -0.35,0.5,-0.35,0.4,-0.26,0.4 );
    glColor3ub(166, 166, 166);
    drawQuad(-0.2,0, -0.4,0,-0.4,0.48, -0.2,0.4);
glColor3ub(191, 191, 191);
   drawQuad(-0.4,0.1, -0.4,0.48, -0.6,0.44, -0.6,0.1);
    glColor3ub(191, 191, 191);
    drawQuad(-0.7,0.32, -0.9,0.32,-0.9,-0.1,-0.7,-0.1);
glColor3ub(204, 204, 204);
   drawQuad(-0.6,-0.1,- 0.6,0.44, -0.8,0.41, -0.8,-0.1);
glColor3ub(153, 77, 0);
    drawQuad(-0.3,0, -0.4,0.1,-0.78,0.1,- 0.78,-0.1);
glColor3ub(255,255,255);
   drawQuad(-0.3,0, -0.4,0.1, -0.42,0.1,- 0.32,0);
glColor3ub(255,255,255);
   drawQuad(-0.48,0, -0.58,0.1, -0.6,0.1, -0.5,0);
glColor3ub(217, 217, 217);
   drawQuad(0.5,0, 0.9,-0.1, -0.9,-0.1, -0.5,0);
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.1);
        glVertex2f(-0.4,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.3);
        glVertex2f(-0.4,0.4);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.2,0.2);
        glVertex2f(-0.4,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.4,0.2);
        glVertex2f(-0.8,0.2);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.4,0.3);
        glVertex2f(-0.8,0.3);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.4,0.4);
        glVertex2f(-0.8,0.4);
        glEnd();
         glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.7,0.1);
        glVertex2f(-0.7,0.42);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.3,0);
        glVertex2f(-0.3,0.44);
        glEnd();
        glBegin(GL_LINES);
        glColor3ub(255,255,255);
        glVertex2f(-0.5,0.1);
        glVertex2f(-0.5,0.46);
        glEnd();
glColor3ub(102, 68, 0);
    drawQuad(0.1,0.02, 0.1,-0.06,-0.1,-0.06, -0.1,0.02);
glColor3ub(77, 77, 0);
   drawQuad(-0.59,0.1, -0.61,0.1, -0.61,0.43, -0.59,0.44);
	int u1;
    GLfloat a111=-.3f; GLfloat b111=.1f; GLfloat radius111 =.05f;
	glColor3ub(51, 51, 0);
	int triangleAmount111 = 10; //# of triangles used to draw circle
	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi111 = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a111, b111); // center of circle
		for(u1= 0; u1 <= triangleAmount11;u1++) {
			glVertex2f(
		            a111+ (radius111 * cos(u1 *  twicePi11 / triangleAmount11)),
			    b111 + (radius111 * sin(u1 * twicePi11 / triangleAmount11))
			);
		}
	glEnd();
	glBegin(GL_TRIANGLES);
        glColor3ub(51, 51, 0);
        glVertex2f(-0.48,0.4);
        glVertex2f(-0.52,0.2);
        glVertex2f(-0.42,0.2);
  glEnd();
         glColor3ub(51, 51, 0);
drawQuad(-0.52,0.1, -0.42,0.1,-0.42,0.15,-0.52,0.15);
	glBegin(GL_TRIANGLES);
        glColor3ub(51, 51, 0);
        glVertex2f(-0.7,0.4);
        glVertex2f(-0.65,0.2);
        glVertex2f(-0.72,0.2);
  glEnd();
           glColor3ub(51, 51, 0);
drawQuad( -0.72,0.1,-0.65,0.1,-0.65,0.15,-0.72,0.15);

glColor3ub(230, 230, 230);
drawQuad(-0.7,-0.05, 0.7,-0.05, 0.9,-0.1,-0.9,-0.1);
glColor3ub(191, 191, 191);
drawQuad(-0.9,-0.1, 0.9,-0.1, 0.9,-0.13,-0.9,-0.13);
glColor3ub(230, 230, 230);
drawQuad(-0.9,-0.13, 0.9,-0.13, 0.93,-0.16,-0.93,-0.16);
glColor3ub(179, 179, 179);
drawQuad(-0.93,-0.16, 0.93,-0.16, 0.93,-0.19,-0.93,-0.19);
glLoadIdentity();
}

void Road()
{
    ///Road
        glTranslatef(0,-0.495,0 );
        glScalef(1.0,.5,0);
        glBegin(GL_QUADS);  /// Road
        glColor3ub(103, 100, 115);
        glVertex2f(1,.1);
        glVertex2f(-1,.1);
        glVertex2f(-1,-.5);
        glVertex2f(1,-.5);
        glEnd();
        glBegin(GL_LINES);  ///Road Mid Line
        glColor3ub(255, 255, 255);
        glVertex2f(-.1,-.2);
        glVertex2f(-.3,-.2);
        glVertex2f(-.4,-.2);
        glVertex2f(-.6,-.2);
        glVertex2f(-.7,-.2);
        glVertex2f(-.9,-.2);
        glVertex2f(.3,-.2);
        glVertex2f(.1,-.2);
        glVertex2f(.6,-.2);
        glVertex2f(.4,-.2);
        glVertex2f(.9,-.2);
        glVertex2f(.7,-.2);
        glEnd();
        glLoadIdentity();

        ///Road_Side_Down
        glTranslatef(0,-.745,0 );
        glScalef(1.0,.3,0);
        glBegin(GL_QUADS);
	glColor3ub(217, 217, 217);
	glVertex2f(-1,0);
	glVertex2f(-1, -.1);
	glVertex2f(-0.7, -0.1);
	glVertex2f(-0.7,0);
	glEnd();
    glBegin(GL_QUADS);
	glColor3ub(0, 0, 0);
	glVertex2f(-.7,.0);
	glVertex2f(-.7, -.1);
	glVertex2f(-.4, -.1);
	glVertex2f(-.4,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217, 217, 217);
	glVertex2f(-.4,.0);
	glVertex2f(-.4, -.1);
	glVertex2f(0, -.1);
	glVertex2f(0,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
	glVertex2f(0,.0);
	glVertex2f(0, -.1);
	glVertex2f(.3, -.1);
	glVertex2f(.3,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217,217,217);
	glVertex2f(.3,.0);
	glVertex2f(.3, -.1);
	glVertex2f(.6, -.1);
	glVertex2f(.6,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217,217,217);
	glVertex2f(.6,.0);
	glVertex2f(.6,-.1);
	glVertex2f(.7, -.1);
	glVertex2f(.7,0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
	glVertex2f(.7,.0);
	glVertex2f(.7,-.1);
	glVertex2f(1.0, -.1);
	glVertex2f(1.0,0);
	glEnd();
	glLoadIdentity();


	///Road_Side_Up
        glTranslatef(0,-.414,0 );
        glScalef(1.0,.3,0);
        glBegin(GL_QUADS);
	glColor3ub(217, 217, 217);
	glVertex2f(-1,0);
	glVertex2f(-1, -.1);
	glVertex2f(-0.7, -0.1);
	glVertex2f(-0.7,0);
	glEnd();
    glBegin(GL_QUADS);
	glColor3ub(0, 0, 0);
	glVertex2f(-.7,.0);
	glVertex2f(-.7, -.1);
	glVertex2f(-.4, -.1);
	glVertex2f(-.4,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217, 217, 217);
	glVertex2f(-.4,.0);
	glVertex2f(-.4, -.1);
	glVertex2f(0, -.1);
	glVertex2f(0,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
	glVertex2f(0,.0);
	glVertex2f(0, -.1);
	glVertex2f(.3, -.1);
	glVertex2f(.3,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217,217,217);
	glVertex2f(.3,.0);
	glVertex2f(.3, -.1);
	glVertex2f(.6, -.1);
	glVertex2f(.6,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217,217,217);
	glVertex2f(.6,.0);
	glVertex2f(.6,-.1);
	glVertex2f(.7, -.1);
	glVertex2f(.7,0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
	glVertex2f(.7,.0);
	glVertex2f(.7,-.1);
	glVertex2f(1.0, -.1);
	glVertex2f(1.0,0);
	glEnd();
	glLoadIdentity();
}

void Road_Night()
{
    ///Road
        glTranslatef(0,-0.495,0 );
        glScalef(1.0,.5,0);
        glBegin(GL_QUADS);  /// Road
        glColor3ub(51, 51, 51);
        glVertex2f(1,.1);
        glVertex2f(-1,.1);
        glVertex2f(-1,-.5);
        glVertex2f(1,-.5);
        glEnd();
        glBegin(GL_LINES);  ///Road Mid Line
        glColor3ub(255, 255, 255);
        glVertex2f(-.1,-.2);
        glVertex2f(-.3,-.2);
        glVertex2f(-.4,-.2);
        glVertex2f(-.6,-.2);
        glVertex2f(-.7,-.2);
        glVertex2f(-.9,-.2);
        glVertex2f(.3,-.2);
        glVertex2f(.1,-.2);
        glVertex2f(.6,-.2);
        glVertex2f(.4,-.2);
        glVertex2f(.9,-.2);
        glVertex2f(.7,-.2);
        glEnd();
        glLoadIdentity();

        ///Road_Side_Down
        glTranslatef(0,-.745,0 );
        glScalef(1.0,.3,0);
        glBegin(GL_QUADS);
	glColor3ub(217, 217, 217);
	glVertex2f(-1,0);
	glVertex2f(-1, -.1);
	glVertex2f(-0.7, -0.1);
	glVertex2f(-0.7,0);
	glEnd();
    glBegin(GL_QUADS);
	glColor3ub(0, 0, 0);
	glVertex2f(-.7,.0);
	glVertex2f(-.7, -.1);
	glVertex2f(-.4, -.1);
	glVertex2f(-.4,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217, 217, 217);
	glVertex2f(-.4,.0);
	glVertex2f(-.4, -.1);
	glVertex2f(0, -.1);
	glVertex2f(0,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
	glVertex2f(0,.0);
	glVertex2f(0, -.1);
	glVertex2f(.3, -.1);
	glVertex2f(.3,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217,217,217);
	glVertex2f(.3,.0);
	glVertex2f(.3, -.1);
	glVertex2f(.6, -.1);
	glVertex2f(.6,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217,217,217);
	glVertex2f(.6,.0);
	glVertex2f(.6,-.1);
	glVertex2f(.7, -.1);
	glVertex2f(.7,0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
	glVertex2f(.7,.0);
	glVertex2f(.7,-.1);
	glVertex2f(1.0, -.1);
	glVertex2f(1.0,0);
	glEnd();
	glLoadIdentity();

	///Road_Side_Up
        glTranslatef(0,-.414,0 );
        glScalef(1.0,.3,0);
        glBegin(GL_QUADS);
	glColor3ub(217, 217, 217);
	glVertex2f(-1,0);
	glVertex2f(-1, -.1);
	glVertex2f(-0.7, -0.1);
	glVertex2f(-0.7,0);
	glEnd();
    glBegin(GL_QUADS);
	glColor3ub(0, 0, 0);
	glVertex2f(-.7,.0);
	glVertex2f(-.7, -.1);
	glVertex2f(-.4, -.1);
	glVertex2f(-.4,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217, 217, 217);
	glVertex2f(-.4,.0);
	glVertex2f(-.4, -.1);
	glVertex2f(0, -.1);
	glVertex2f(0,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
	glVertex2f(0,.0);
	glVertex2f(0, -.1);
	glVertex2f(.3, -.1);
	glVertex2f(.3,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217,217,217);
	glVertex2f(.3,.0);
	glVertex2f(.3, -.1);
	glVertex2f(.6, -.1);
	glVertex2f(.6,.0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(217,217,217);
	glVertex2f(.6,.0);
	glVertex2f(.6,-.1);
	glVertex2f(.7, -.1);
	glVertex2f(.7,0);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
	glVertex2f(.7,.0);
	glVertex2f(.7,-.1);
	glVertex2f(1.0, -.1);
	glVertex2f(1.0,0);
	glEnd();
	glLoadIdentity();
}

void Car1()
{
    ///Yellow_car
        glTranslatef(-1.0,-.51,0 );
        glScalef(.5,.5,0);
        glBegin(GL_QUADS);
        glColor3ub(255, 255, 77);
        glVertex2f(.6,-.36);
        glVertex2f(.2,-.36);
        glVertex2f(.2,-.4);
        glVertex2f(.6,-.4);
        glVertex2f(.54,-.24);
        glVertex2f(.14,-.24);
        glVertex2f(.2,-.36);
        glVertex2f(.6,-.36);
        glVertex2f(.14,-.24);
        glVertex2f(.14,-.28);
        glVertex2f(.2,-.4);
        glVertex2f(.2,-.36);
        glVertex2f(.39,-.18);
        glVertex2f(.24,-.18);
        glVertex2f(.3,-.3);
        glVertex2f(.44,-.3);
        glEnd();
        glBegin(GL_QUADS);
        glColor3ub(128, 223, 255);
        glVertex2f(.3,-.3);
        glVertex2f(.24,-.18);
        glVertex2f(.2,-.24);
        glVertex2f(.26,-.36);
        glVertex2f(.38,-.3);
        glVertex2f(.3,-.3);
        glVertex2f(.26,-.36);
        glVertex2f(.38,-.36);
        glVertex2f(.44,-.3);
        glVertex2f(.38,-.3);
        glVertex2f(.38,-.36);
        glVertex2f(.46,-.36);
        glEnd();
        glBegin(GL_LINES);  ///new car Line
        glColor3ub(0, 0, 0);
        glVertex2f(.6,-.36);
        glVertex2f(.2,-.36);
        glVertex2f(.2,-.36);
        glVertex2f(.2,-.4);
        glVertex2f(.6,-.4);
        glVertex2f(.2,-.4);
        glVertex2f(.6,-.36);
        glVertex2f(.6,-.4);
        glVertex2f(.14,-.24);
        glVertex2f(.14,-.28);
        glVertex2f(.14,-.28);
        glVertex2f(.2,-.4);
        glVertex2f(.14,-.24);
        glVertex2f(.2,-.36);
        glVertex2f(.14,-.24);
        glVertex2f(.2,-.24);
        glVertex2f(.3,-.3);
        glVertex2f(.24,-.18);
        glVertex2f(.24,-.18);
        glVertex2f(.2,-.24);
        glVertex2f(.2,-.24);
        glVertex2f(.26,-.36);
        glVertex2f(.38,-.3);
        glVertex2f(.3,-.3);
        glVertex2f(.3,-.3);
        glVertex2f(.26,-.36);
        glVertex2f(.26,-.36);
        glVertex2f(.38,-.36);
        glVertex2f(.44,-.3);
        glVertex2f(.38,-.3);
        glVertex2f(.38,-.3);
        glVertex2f(.38,-.36);
        glVertex2f(.38,-.36);
        glVertex2f(.46,-.36);
        glVertex2f(.46,-.36);
        glVertex2f(.44,-.3);
        glVertex2f(.38,-.36);
        glVertex2f(.38,-.3);
        glVertex2f(.26,-.36);
        glVertex2f(.3,-.3);
        glVertex2f(.54,-.24);
        glVertex2f(.6,-.36);
        glVertex2f(.54,-.24);
        glVertex2f(.415,-.24);
        glVertex2f(.44,-.3);
        glVertex2f(.39,-.18);
        glVertex2f(.39,-.18);
        glVertex2f(.24,-.18);
        glEnd();
        glColor3ub(0, 0, 0);
        drawCircle(.3,-.42,.035);
        drawCircle(.46,-.42,.035);
        glColor3ub(255, 255, 255);
        drawCircle(.3,-.42,.02);
        drawCircle(.46,-.42f,.02);
        glLoadIdentity();
}
void Car2()
{
    ///Blue_car
        glTranslatef(1.0,-.36,0 );
        glScalef(.5,.5,0);
        glBegin(GL_QUADS);
        glColor3ub(51, 51, 255);
        glVertex2f(-.6,-.36);
        glVertex2f(-.2,-.36);
        glVertex2f(-.2,-.4);
        glVertex2f(-.6,-.4);
        glVertex2f(-.54,-.24);
        glVertex2f(-.14,-.24);
        glVertex2f(-.2,-.36);
        glVertex2f(-.6,-.36);
        glVertex2f(-.14,-.24);
        glVertex2f(-.14,-.28);
        glVertex2f(-.2,-.4);
        glVertex2f(-.2,-.36);
        glVertex2f(-.39,-.18);
        glVertex2f(-.24,-.18);
        glVertex2f(-.3,-.3);
        glVertex2f(-.44,-.3);
        glEnd();
        glBegin(GL_QUADS);
        glColor3ub(255, 255, 255);
        glVertex2f(-.3,-.3);
        glVertex2f(-.24,-.18);
        glVertex2f(-.2,-.24);
        glVertex2f(-.26,-.36);
        glVertex2f(-.38,-.3);
        glVertex2f(-.3,-.3);
        glVertex2f(-.26,-.36);
        glVertex2f(-.38,-.36);
        glVertex2f(-.44,-.3);
        glVertex2f(-.38,-.3);
        glVertex2f(-.38,-.36);
        glVertex2f(-.46,-.36);
        glEnd();
        glBegin(GL_LINES);  ///new car Line
        glColor3ub(0, 0, 0);
        glVertex2f(-.6,-.36);
        glVertex2f(-.2,-.36);
        glVertex2f(-.2,-.36);
        glVertex2f(-.2,-.4);
        glVertex2f(-.6,-.4);
        glVertex2f(-.2,-.4);
        glVertex2f(-.6,-.36);
        glVertex2f(-.6,-.4);
        glVertex2f(-.14,-.24);
        glVertex2f(-.14,-.28);
        glVertex2f(-.14,-.28);
        glVertex2f(-.2,-.4);
        glVertex2f(-.14,-.24);
        glVertex2f(-.2,-.36);
        glVertex2f(-.14,-.24);
        glVertex2f(-.2,-.24);
        glVertex2f(-.3,-.3);
        glVertex2f(-.24,-.18);
        glVertex2f(-.24,-.18);
        glVertex2f(-.2,-.24);
        glVertex2f(-.2,-.24);
        glVertex2f(-.26,-.36);
        glVertex2f(-.38,-.3);
        glVertex2f(-.3,-.3);
        glVertex2f(-.3,-.3);
        glVertex2f(-.26,-.36);
        glVertex2f(-.26,-.36);
        glVertex2f(-.38,-.36);
        glVertex2f(-.44,-.3);
        glVertex2f(-.38,-.3);
        glVertex2f(-.38,-.3);
        glVertex2f(-.38,-.36);
        glVertex2f(-.38,-.36);
        glVertex2f(-.46,-.36);
        glVertex2f(-.46,-.36);
        glVertex2f(-.44,-.3);
        glVertex2f(-.38,-.36);
        glVertex2f(-.38,-.3);
        glVertex2f(-.26,-.36);
        glVertex2f(-.3,-.3);
        glVertex2f(-.54,-.24);
        glVertex2f(-.6,-.36);
        glVertex2f(-.54,-.24);
        glVertex2f(-.415,-.24);
        glVertex2f(-.44,-.3);
        glVertex2f(-.39,-.18);
        glVertex2f(-.39,-.18);
        glVertex2f(-.24,-.18);
        glEnd();
        glColor3ub(0, 0, 0);
        drawCircle(-.3,-.42,.035);
        drawCircle(-.46,-.42,.035);
        glColor3ub(255, 255, 255);
        drawCircle(-.3,-.42,.02);
        drawCircle(-.46,-.42,.02);
        glLoadIdentity();
}
void Cloud1()
{
    ///Clouds
        glTranslatef(.5,.6,0 );
        glScalef(.4,.4,0);
        glColor3ub(216, 230, 243);
        drawCircle(.03,.64,.08);
        drawCircle(0.11,.56,.08);
        drawCircle(.22,.48,.08f);
        glColor3ub(216, 240, 243);
        drawCircle(.12,.46,.08);
        drawCircle(.01,.46,.08);
        drawCircle(-0.12,.5,.08);
        drawCircle(-0.06,.57,.08);
        drawCircle(0.02,.52,.08);
        glLoadIdentity();
}

void Cloud3()
{
    ///Clouds
        glTranslatef(-.5,.6,0 );
        glScalef(.4,.4,0);
        glColor3ub(216, 230, 243);
        drawCircle(.03,.64,.08);
        drawCircle(0.11,.56,.08);
        drawCircle(.22,.48,.08f);
        glColor3ub(216, 240, 243);
        drawCircle(.12,.46,.08);
        drawCircle(.01,.46,.08);
        drawCircle(-0.12,.5,.08);
        drawCircle(-0.06,.57,.08);
        drawCircle(0.02,.52,.08);
        glLoadIdentity();
}
void Cloud2()
{
    ///Clouds
        glTranslatef(.1,.5,0 );
        glScalef(.4,.4,0);
        glColor3ub(216, 230, 243);
        drawCircle(.03,.64,.08);
        drawCircle(0.11,.56,.08);
        drawCircle(.22,.48,.08f);
        glColor3ub(216, 240, 243);
        drawCircle(.12,.46,.08);
        drawCircle(.01,.46,.08);
        drawCircle(-0.12,.5,.08);
        drawCircle(-0.06,.57,.08);
        drawCircle(0.02,.52,.08);
        glLoadIdentity();
}
void Cloud4()
{
    ///Clouds
        glTranslatef(-.6,.5,0 );
        glScalef(.4,.4,0);
        glColor3ub(216, 230, 243);
        drawCircle(.03,.64,.08);
        drawCircle(0.11,.56,.08);
        drawCircle(.22,.48,.08f);
        glColor3ub(216, 240, 243);
        drawCircle(.12,.46,.08);
        drawCircle(.01,.46,.08);
        drawCircle(-0.12,.5,.08);
        drawCircle(-0.06,.57,.08);
        drawCircle(0.02,.52,.08);
        glLoadIdentity();
}

void Flower()
{
    ///Flower
        glTranslatef(0.95,-.05,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();
int i;
	GLfloat x=0.0f; GLfloat y=0.05f; GLfloat radius =.1f;
	int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(0.9,-.051,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(0.88,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(0.97,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(0.8,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(0.88,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(0.75,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(0.7,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(0.65,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(0.675,-.05,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(0.725,-.05,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(0.775,.05,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(-0.95,-.05,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();
//int i;
	 x=0.0f;  y=0.05f;  radius =.1f;
	 triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(-0.9,-.051,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(-0.88,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(-0.97,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(-0.8,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(-0.88,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(-0.75,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(-0.7,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(-0.65,-.09,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(-0.675,-.05,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

	///Flower
        glTranslatef(-0.725,-.05,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();


	///Flower
        glTranslatef(-0.775,-.05,0);
	    glScalef(0.2,.1,0);
glBegin(GL_LINES);
glColor3ub(0,153,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,-0.5);
glVertex2f(.17,-0.1);
glVertex2f(0.0,-0.2);
glVertex2f(-0.17,-0.1);
glVertex2f(0.0,-0.2);
glEnd();

	 x=0.0f;  y=0.05f;  radius =.1f;
	//int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
 x=0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=-0.11f;  y=-0.06f;  radius =.1f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,153,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

///1st
	 x=0.0f;  y=0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	 x=0.0f;  y=-0.05f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=-0.05f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3f(1,0,0);

		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
		 x=0.0f;  y=0.0f;  radius =.03f;
 twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glLoadIdentity();

}

void Tree()
{
    ///Tree_Big
         glScalef(.5,0.3,0);
    glTranslatef(2.3,0.3,0);

    glColor3ub(97, 29, 30);
    drawQuad(-0.7,-0.5, -0.7,-0.9, -0.65,-0.9, -0.65,-0.5);
    drawQuad(-0.8,-0.35, -0.7,-0.5, -0.65,-0.5, -0.75,-0.3);
    drawQuad(-0.60,-0.3, -0.68,-0.45, -0.65,-0.5, -0.58,-0.35);
    glColor3ub(42, 122, 59);
    drawCircle(-0.77,-0.3,0.15);
    drawCircle(-0.59,-0.3,0.15);
    drawCircle(-0.67,-0.2,0.2);
    glLoadIdentity();




        ///Tree_Tri1_Dark
    glPushMatrix();
    glScalef(0.3,0.25,0);
    glTranslatef(2.9,-0.5,0);

    glColor3ub(97, 29, 30);
    drawQuad(-0.7,-0.5, -0.7,-0.9, -0.65,-0.9, -0.65,-0.5);
    drawQuad(-0.8,-0.35, -0.7,-0.5, -0.65,-0.5, -0.75,-0.3);
    drawQuad(-0.60,-0.3, -0.68,-0.45, -0.65,-0.5, -0.58,-0.35);
    glColor3ub(0, 153, 0); //leaf
    drawTriangle(-0.7,0, -0.95,-0.45, -0.4,-0.45);
    drawTriangle(-0.7,0.1, -0.95,-0.35, -0.4,-0.35);
    drawTriangle(-0.7,0.15, -0.95,-0.25, -0.4,-0.25);
    glColor3ub(10, 105, 54);
    drawTriangle(-0.85,-0.6, -0.7,-0.9, -0.7,-0.8);
    glPopMatrix();
    glLoadIdentity();

    ///tree_Tri
    glPushMatrix();
    glScalef(0.3,0.25,0);
    glTranslatef(3.8,-0.5,0);
    glColor3ub(97, 29, 30);
    drawQuad(-0.7,-0.5, -0.7,-0.9, -0.65,-0.9, -0.65,-0.5);
    drawQuad(-0.8,-0.35, -0.7,-0.5, -0.65,-0.5, -0.75,-0.3);
    drawQuad(-0.60,-0.3, -0.68,-0.45, -0.65,-0.5, -0.58,-0.35);
    glColor3ub(0, 153, 0); //leaf
    drawTriangle(-0.7,0, -0.95,-0.45, -0.4,-0.45);
    drawTriangle(-0.7,0.1, -0.95,-0.35, -0.4,-0.35);
    drawTriangle(-0.7,0.15, -0.95,-0.25, -0.4,-0.25);
    glColor3ub(10, 105, 54);
    drawTriangle(-0.85,-0.6, -0.7,-0.9, -0.7,-0.8);
    glPopMatrix();
        glLoadIdentity();


        ///Tree_Big
         glScalef(.5,0.3,0);
    glTranslatef(2.3,-0.48,0);

    glColor3ub(97, 29, 30);
    drawQuad(-0.7,-0.5, -0.7,-0.9, -0.65,-0.9, -0.65,-0.5);
    drawQuad(-0.8,-0.35, -0.7,-0.5, -0.65,-0.5, -0.75,-0.3);
    drawQuad(-0.60,-0.3, -0.68,-0.45, -0.65,-0.5, -0.58,-0.35);
    glColor3ub(42, 122, 59);
    drawCircle(-0.77,-0.3,0.15);
    drawCircle(-0.59,-0.3,0.15);
    drawCircle(-0.67,-0.2,0.2);
    glLoadIdentity();


     ///Tree_Big
         glScalef(.5,0.3,0);
    glTranslatef(-1,0.3,0);

    glColor3ub(97, 29, 30);
    drawQuad(-0.7,-0.5, -0.7,-0.9, -0.65,-0.9, -0.65,-0.5);
    drawQuad(-0.8,-0.35, -0.7,-0.5, -0.65,-0.5, -0.75,-0.3);
    drawQuad(-0.60,-0.3, -0.68,-0.45, -0.65,-0.5, -0.58,-0.35);
    glColor3ub(42, 122, 59);
    drawCircle(-0.77,-0.3,0.15);
    drawCircle(-0.59,-0.3,0.15);
    drawCircle(-0.67,-0.2,0.2);
    glLoadIdentity();




        ///Tree_Tri1_Dark
    glPushMatrix();
    glScalef(0.3,0.25,0);
    glTranslatef(-2.4,-0.5,0);

    glColor3ub(97, 29, 30);
    drawQuad(-0.7,-0.5, -0.7,-0.9, -0.65,-0.9, -0.65,-0.5);
    drawQuad(-0.8,-0.35, -0.7,-0.5, -0.65,-0.5, -0.75,-0.3);
    drawQuad(-0.60,-0.3, -0.68,-0.45, -0.65,-0.5, -0.58,-0.35);
    glColor3ub(0, 153, 0); //leaf
    drawTriangle(-0.7,0, -0.95,-0.45, -0.4,-0.45);
    drawTriangle(-0.7,0.1, -0.95,-0.35, -0.4,-0.35);
    drawTriangle(-0.7,0.15, -0.95,-0.25, -0.4,-0.25);
    glColor3ub(10, 105, 54);
    drawTriangle(-0.85,-0.6, -0.7,-0.9, -0.7,-0.8);
    glPopMatrix();
    glLoadIdentity();

    ///tree_Tri
    glPushMatrix();
    glScalef(0.3,0.25,0);
    glTranslatef(-1.7,-0.5,0);
    glColor3ub(97, 29, 30);
    drawQuad(-0.7,-0.5, -0.7,-0.9, -0.65,-0.9, -0.65,-0.5);
    drawQuad(-0.8,-0.35, -0.7,-0.5, -0.65,-0.5, -0.75,-0.3);
    drawQuad(-0.60,-0.3, -0.68,-0.45, -0.65,-0.5, -0.58,-0.35);
    glColor3ub(0, 153, 0); //leaf
    drawTriangle(-0.7,0, -0.95,-0.45, -0.4,-0.45);
    drawTriangle(-0.7,0.1, -0.95,-0.35, -0.4,-0.35);
    drawTriangle(-0.7,0.15, -0.95,-0.25, -0.4,-0.25);
    glColor3ub(10, 105, 54);
    drawTriangle(-0.85,-0.6, -0.7,-0.9, -0.7,-0.8);
    glPopMatrix();
        glLoadIdentity();


        ///Tree_Big
         glScalef(.5,0.3,0);
    glTranslatef(-1,-0.48,0);

    glColor3ub(97, 29, 30);
    drawQuad(-0.7,-0.5, -0.7,-0.9, -0.65,-0.9, -0.65,-0.5);
    drawQuad(-0.8,-0.35, -0.7,-0.5, -0.65,-0.5, -0.75,-0.3);
    drawQuad(-0.60,-0.3, -0.68,-0.45, -0.65,-0.5, -0.58,-0.35);
    glColor3ub(42, 122, 59);
    drawCircle(-0.77,-0.3,0.15);
    drawCircle(-0.59,-0.3,0.15);
    drawCircle(-0.67,-0.2,0.2);
    glLoadIdentity();
///Left___________________

///Grass_Littler
    glPushMatrix();
    float bx=0.6;
    float by=-0.8;
    glTranslatef(-1.39,-0.23,0);
    glScalef(1.3,0.17,0);
    glBegin(GL_POLYGON);
    glColor3f(0.0,0.6,0.1);
    glVertex2f(-0.245+bx,-0.20+by);
    glVertex2f(-0.230+bx,0+by);
    glVertex2f(-0.220+bx,0.10+by);
    glVertex2f(-0.240+bx,0+by);
    glVertex2f(-0.230+bx,0.30+by);
    glVertex2f(-0.250+bx,0.10+by);
    glVertex2f(-0.255+bx,0.50+by);
    glColor3f(0.6,0.8,0.1);
    glVertex2f(-0.260+bx,0.10+by);
    glVertex2f(-0.280+bx,0.30+by);
    glVertex2f(-0.270+bx,0.0+by);
    glVertex2f(-0.290+bx,0.10+by);
    glVertex2f(-0.280+bx,0.0+by);
    glVertex2f(-0.265+bx,-0.20+by);
    glEnd();
    glPopMatrix();
    glLoadIdentity();

    ///Grass_Littler
    glPushMatrix();
    glTranslatef(-1.1,-0.23,0);
    glScalef(1.3,0.17,0);
    glBegin(GL_POLYGON);
    glColor3f(0.0,0.6,0.1);
    glVertex2f(-0.245+bx,-0.20+by);
    glVertex2f(-0.230+bx,0+by);
    glVertex2f(-0.220+bx,0.10+by);
    glVertex2f(-0.240+bx,0+by);
    glVertex2f(-0.230+bx,0.30+by);
    glVertex2f(-0.250+bx,0.10+by);
    glVertex2f(-0.255+bx,0.50+by);
    glColor3f(0.6,0.8,0.1);
    glVertex2f(-0.260+bx,0.10+by);
    glVertex2f(-0.280+bx,0.30+by);
    glVertex2f(-0.270+bx,0.0+by);
    glVertex2f(-0.290+bx,0.10+by);
    glVertex2f(-0.280+bx,0.0+by);
    glVertex2f(-0.265+bx,-0.20+by);
    glEnd();
    glPopMatrix();
    glLoadIdentity();


    ///Grass_Littler
    glPushMatrix();
    glTranslatef(-0.81,-0.23,0);
    glScalef(1.3,0.17,0);
    glBegin(GL_POLYGON);
    glColor3f(0.0,0.6,0.1);
    glVertex2f(-0.245+bx,-0.20+by);
    glVertex2f(-0.230+bx,0+by);
    glVertex2f(-0.220+bx,0.10+by);
    glVertex2f(-0.240+bx,0+by);
    glVertex2f(-0.230+bx,0.30+by);
    glVertex2f(-0.250+bx,0.10+by);
    glVertex2f(-0.255+bx,0.50+by);
    glColor3f(0.6,0.8,0.1);
    glVertex2f(-0.260+bx,0.10+by);
    glVertex2f(-0.280+bx,0.30+by);
    glVertex2f(-0.270+bx,0.0+by);
    glVertex2f(-0.290+bx,0.10+by);
    glVertex2f(-0.280+bx,0.0+by);
    glVertex2f(-0.265+bx,-0.20+by);
    glEnd();
    glPopMatrix();
    glLoadIdentity();


        ///Grass_Littler
    glPushMatrix();
    glTranslatef(-0.52,-0.23,0);
    glScalef(1.3,0.17,0);
    glBegin(GL_POLYGON);
    glColor3f(0.0,0.6,0.1);
    glVertex2f(-0.245+bx,-0.20+by);
    glVertex2f(-0.230+bx,0+by);
    glVertex2f(-0.220+bx,0.10+by);
    glVertex2f(-0.240+bx,0+by);
    glVertex2f(-0.230+bx,0.30+by);
    glVertex2f(-0.250+bx,0.10+by);
    glVertex2f(-0.255+bx,0.50+by);
    glColor3f(0.6,0.8,0.1);
    glVertex2f(-0.260+bx,0.10+by);
    glVertex2f(-0.280+bx,0.30+by);
    glVertex2f(-0.270+bx,0.0+by);
    glVertex2f(-0.290+bx,0.10+by);
    glVertex2f(-0.280+bx,0.0+by);
    glVertex2f(-0.265+bx,-0.20+by);
    glEnd();
    glPopMatrix();
    glLoadIdentity();

        ///Grass_Littler
    glPushMatrix();
    glTranslatef(-0.23,-0.23,0);
    glScalef(1.3,0.17,0);
    glBegin(GL_POLYGON);
    glColor3f(0.0,0.6,0.1);
    glVertex2f(-0.245+bx,-0.20+by);
    glVertex2f(-0.230+bx,0+by);
    glVertex2f(-0.220+bx,0.10+by);
    glVertex2f(-0.240+bx,0+by);
    glVertex2f(-0.230+bx,0.30+by);
    glVertex2f(-0.250+bx,0.10+by);
    glVertex2f(-0.255+bx,0.50+by);
    glColor3f(0.6,0.8,0.1);
    glVertex2f(-0.260+bx,0.10+by);
    glVertex2f(-0.280+bx,0.30+by);
    glVertex2f(-0.270+bx,0.0+by);
    glVertex2f(-0.290+bx,0.10+by);
    glVertex2f(-0.280+bx,0.0+by);
    glVertex2f(-0.265+bx,-0.20+by);
    glEnd();
    glPopMatrix();
    glLoadIdentity();

        ///Grass_Littler
    glPushMatrix();
    glTranslatef(0.06,-0.23,0);
    glScalef(1.3,0.17,0);
    glBegin(GL_POLYGON);
    glColor3f(0.0,0.6,0.1);
    glVertex2f(-0.245+bx,-0.20+by);
    glVertex2f(-0.230+bx,0+by);
    glVertex2f(-0.220+bx,0.10+by);
    glVertex2f(-0.240+bx,0+by);
    glVertex2f(-0.230+bx,0.30+by);
    glVertex2f(-0.250+bx,0.10+by);
    glVertex2f(-0.255+bx,0.50+by);
    glColor3f(0.6,0.8,0.1);
    glVertex2f(-0.260+bx,0.10+by);
    glVertex2f(-0.280+bx,0.30+by);
    glVertex2f(-0.270+bx,0.0+by);
    glVertex2f(-0.290+bx,0.10+by);
    glVertex2f(-0.280+bx,0.0+by);
    glVertex2f(-0.265+bx,-0.20+by);
    glEnd();
    glPopMatrix();
    glLoadIdentity();

        ///Grass_Littler
    glPushMatrix();
    glTranslatef(0.33,-0.23,0);
    glScalef(1.3,0.17,0);
    glBegin(GL_POLYGON);
    glColor3f(0.0,0.6,0.1);
    glVertex2f(-0.245+bx,-0.20+by);
    glVertex2f(-0.230+bx,0+by);
    glVertex2f(-0.220+bx,0.10+by);
    glVertex2f(-0.240+bx,0+by);
    glVertex2f(-0.230+bx,0.30+by);
    glVertex2f(-0.250+bx,0.10+by);
    glVertex2f(-0.255+bx,0.50+by);
    glColor3f(0.6,0.8,0.1);
    glVertex2f(-0.260+bx,0.10+by);
    glVertex2f(-0.280+bx,0.30+by);
    glVertex2f(-0.270+bx,0.0+by);
    glVertex2f(-0.290+bx,0.10+by);
    glVertex2f(-0.280+bx,0.0+by);
    glVertex2f(-0.265+bx,-0.20+by);
    glEnd();
    glPopMatrix();
    glLoadIdentity();
}

void Lamp()
{
    ///Lamp_down

	glTranslatef(.1,-.76,0);
	glScalef(0.18,0.4,0);

	//glLineWidth(5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.7,.0);    // x, y
	glVertex2f(-.7,.3);    // x, y
	glEnd();
	 //glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.58,.17);    // x, y
	glEnd();
	 //glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.82,.29);    // x, y
	glEnd();
	//glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.58,.17);    // x, y
	glVertex2f(-.58,.29);    // x, y
	glEnd();

        glColor3ub(230, 230, 0);
        drawCircle(-.7,.3,.06);
        glColor3ub(255, 255, 153);
	    drawCircle( -.82,.26 ,.05);
	    glColor3ub(255, 255, 153);
	    drawCircle( -.58,.26,.05);
	    glLoadIdentity();

	    ///
	    glTranslatef(.9,-.76,0);
	glScalef(0.18,0.4,0);

	//glLineWidth(5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.7,.0);    // x, y
	glVertex2f(-.7,.3);    // x, y
	glEnd();
	 //glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.58,.17);    // x, y
	glEnd();
	 //glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.82,.29);    // x, y
	glEnd();
	//glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.58,.17);    // x, y
	glVertex2f(-.58,.29);    // x, y
	glEnd();

        glColor3ub(230, 230, 0);
        drawCircle(-.7,.3,.06);
        glColor3ub(255, 255, 153);
	    drawCircle( -.82,.26 ,.05);
	    glColor3ub(255, 255, 153);
	    drawCircle( -.58,.26,.05);
	    glLoadIdentity();

	    ///
	    glTranslatef(-.7,-.76,0);
	glScalef(0.18,0.4,0);

	//glLineWidth(5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.7,.0);    // x, y
	glVertex2f(-.7,.3);    // x, y
	glEnd();
	 //glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.58,.17);    // x, y
	glEnd();
	 //glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.82,.29);    // x, y
	glEnd();
	//glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.58,.17);    // x, y
	glVertex2f(-.58,.29);    // x, y
	glEnd();

        glColor3ub(230, 230, 0);
        drawCircle(-.7,.3,.06);
        glColor3ub(255, 255, 153);
	    drawCircle( -.82,.26 ,.05);
	    glColor3ub(255, 255, 153);
	    drawCircle( -.58,.26,.05);
	    glLoadIdentity();


    ///Lamp_Up
	glTranslatef(.5,-.44,0);
	glScalef(0.18,0.4,0);

	//glLineWidth(5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.7,.0);    // x, y
	glVertex2f(-.7,.3);    // x, y
	glEnd();
	// glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.58,.17);    // x, y
	glEnd();
	 //glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.82,.29);    // x, y
	glEnd();
	//glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.58,.17);    // x, y
	glVertex2f(-.58,.29);    // x, y
	glEnd();

        glColor3ub(230, 230, 0);
        drawCircle(-.7,.3,.06);
        glColor3ub(255, 255, 153);
	    drawCircle( -.82,.26 ,.05);
	    glColor3ub(255, 255, 153);
	    drawCircle( -.58,.26,.05);
	    glLoadIdentity();


	    ///
	    glTranslatef(-.3,-.44,0);
	glScalef(0.18,0.4,0);

	//glLineWidth(5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.7,.0);    // x, y
	glVertex2f(-.7,.3);    // x, y
	glEnd();
	// glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.58,.17);    // x, y
	glEnd();
	 //glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.82,.17);    // x, y
	glVertex2f(-.82,.29);    // x, y
	glEnd();
	//glLineWidth(3);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0,0,0);
	glVertex2f(-.58,.17);    // x, y
	glVertex2f(-.58,.29);    // x, y
	glEnd();

        glColor3ub(230, 230, 0);
        drawCircle(-.7,.3,.06);
        glColor3ub(255, 255, 153);
	    drawCircle( -.82,.26 ,.05);
	    glColor3ub(255, 255, 153);
	    drawCircle( -.58,.26,.05);
	    glLoadIdentity();
}

void Helecopter()
{
    glTranslatef(-0.5,1,0);
glScalef(-0.5,0.5,0);

//Body
    glBegin(GL_QUADS);
    glColor3ub(255,0,0);
    glVertex2f(-0.2*.5-.65f,0.1*.7-.6f);
    glVertex2f(-0.2*.5-.65f,-0.1*.7-.6f);
    glVertex2f(0.2*.5-.65f,-0.1*.7-.6f);
    glVertex2f(0.05*.5-.65f,0.1*.7-.6f);

 glEnd();
 glBegin(GL_QUADS);
    glColor3ub(0,204,204);
    glVertex2f(-0.05*.5-.65f,0.1*.4-.6f);
    glVertex2f(-0.05*.5-.65f,-0.07*.7-.6f);
    glVertex2f(0.05*.5-.65f,-0.08*.4-.6f);
    glVertex2f(0.05*.5-.65f,0.08*.7-.6f);

 glEnd();

//Tail
 glColor3f(0, 0, 0);
 //glLineWidth(2);
 //glLineWidth(2);
 glBegin(GL_LINES);
    glVertex2f(-0.4*.5-.65f,0.07*.7-.6f);
    glVertex2f(-0.2*.5-.65f,0.07*.7-.6f);

    glVertex2f(-0.4*.5-.65f,0.04*.7-.6f);
    glVertex2f(-0.2*.5-.65f,0.04*.7-.6f);

     glVertex2f(-0.1*.5-.65f,-0.1*.7-.6f);
    glVertex2f(-0.06*.5-.65f,-0.160*.7-.6f);

    glVertex2f(-0.1*.5-.65f,-0.160*.7-.6f);
    glVertex2f(-0.02*.5-.65f,-0.160*.7-.6f);

    glVertex2f(0.05*.5-.65f,-0.1*.7-.6f);
    glVertex2f(0.09*.5-.65f,-0.180*.7-.6f);

    glVertex2f(-0.08*.5-.65f,-0.180*.7-.6f);
    glVertex2f(0.110*.5-.65f,-0.180*.7-.6f);

    glVertex2f(0.110*.5-.65f,-0.180*.7-.6f);
    glVertex2f(0.130*.5-.65f,-0.150*.7-.6f);

    //fan

    glVertex2f(-0.05*.5-.65f,0.1*.7-.6f);
    glVertex2f(-0.05*.5-.65f,0.150*.7-.6f);

    glVertex2f(-0.05*.5-.65f,0.150*.7-.6f);
    glVertex2f(0.05*.5-.65f,0.190*.7-.6f);

    glVertex2f(-0.05*.5-.65f,0.150*.7-.6f);
    glVertex2f(-0.15*.5-.65f,0.190*.7-.6f);
    glEnd();
     glColor3ub(355, 355, 0);
 //glLineWidth(4);
 glBegin(GL_LINES);
    glVertex2f(-0.4*.5-.65f,0.07*.7-.6f);
    glVertex2f(-0.450*.5-.65f,0.150*.7-.6f);

   glVertex2f(-0.4*.5-.65f,0.04*.7-.6f);
    glVertex2f(-0.450*.5-.65f,-0.06*.7-.6f);

     glEnd();;
glLoadIdentity();
}
void Bird()
{
    glTranslatef(-0.2,-0.8,0);
glScalef(1,1,0);
    int g;

    GLfloat a=.182f; GLfloat b=.801f; GLfloat radius1 =.01f;
	glColor3ub(0, 153, 204);
	int triangleAmount1 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi1 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a, b); // center of circle
		for(g = 0; g <= triangleAmount1;g++) {
			glVertex2f(
		            a+ (radius1 * cos(g *  twicePi1 / triangleAmount1)),
			    b + (radius1 * sin(g * twicePi1 / triangleAmount1))
			);
		}
	glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(0, 153, 204);
        glVertex2f(0.1f,0.8f);
        glVertex2f(0.11f,0.79f);
        glVertex2f(0.12f,0.78f);
        glVertex2f(0.16f,0.77f);
        glVertex2f(0.19f,0.79f);
        glVertex2f(0.201f,0.8f);
        glEnd();

        glBegin(GL_TRIANGLES);
        glColor3ub(0, 153, 204);
        glVertex2f(0.175f,0.8f);
        glVertex2f(0.15f,0.8f);
        glVertex2f(0.14f,0.84f);
        glEnd();


        glBegin(GL_TRIANGLES);
        glColor3ub(0, 153, 204 );
        glVertex2f(0.175f,0.8f);
        glVertex2f(0.144f,0.8f);
        glVertex2f(0.12f,0.83f);
        glEnd();





                             ///  BIRD BIRD BIRD BIRD                 BIRD 2                   BIRD BIRD BIRD BIRD
    glBegin(GL_POLYGON);
        glColor3ub(0, 153, 204 );
        glVertex2f(-0.02f,0.8f);
        glVertex2f(-0.01f,0.79f);
        glVertex2f(0.0f,0.78f);
        glVertex2f(0.04f,0.77f);
        glVertex2f(0.07f,0.79f);
        glVertex2f(0.081f,0.8f);
        glEnd();

        glBegin(GL_TRIANGLES);
        glColor3ub(0, 153, 204);
        glVertex2f(0.055f,0.8f);
        glVertex2f(0.03f,0.8f);
        glVertex2f(0.02f,0.84f);
        glEnd();


        glBegin(GL_TRIANGLES);
        glColor3ub(0, 153, 204 );
        glVertex2f(0.055f,0.8f);
        glVertex2f(0.024f,0.8f);
        glVertex2f(0.0f,0.83f);
        glEnd();




int i;
	GLfloat x1=0.062f; GLfloat y1=.801f; GLfloat radius =0.01f;
	 glColor3ub(0, 153, 204);
	int triangleAmount = 100;


	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x1, y1);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x1 + (radius * cos(i *  twicePi / triangleAmount)),
			    y1 + (radius * sin(i * twicePi / triangleAmount))
			);
		}

	glEnd();


                                ///  BIRD BIRD BIRD BIRD                 BIRD 3                   BIRD BIRD BIRD BIRD
        glBegin(GL_POLYGON);
        glColor3ub(140, 255, 102 );
        glVertex2f(-0.72f,0.8f);
        glVertex2f(-0.71f,0.79f);
        glVertex2f(-0.7f,0.78f);
        glVertex2f(-0.66f,0.77f);
        glVertex2f(-0.63f,0.79f);
        glVertex2f(-0.619f,0.8f);
        glEnd();
        glBegin(GL_TRIANGLES);
        glColor3ub(140, 255, 102);
        glVertex2f(-0.645f,0.8f);
        glVertex2f(-0.67f,0.8f);
        glVertex2f(-0.68f,0.84f);
        glEnd();
        glBegin(GL_TRIANGLES);
        glColor3ub(140, 255, 102 );
        glVertex2f(-0.645f,0.8f);
        glVertex2f(-0.676f,0.8f);
        glVertex2f(-0.7f,0.83f);
        glEnd();




   int u;

    GLfloat a110=-0.638; GLfloat b110=.801f; GLfloat radius110 =.01f;
	glColor3ub(140, 255, 102);
	int triangleAmount110 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi110 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a110, b110); // center of circle
		for(u= 0; u <= triangleAmount110;u++) {
			glVertex2f(
		            a110+ (radius110 * cos(u *  twicePi110 / triangleAmount110)),
			    b110 + (radius110 * sin(u * twicePi110 / triangleAmount110))
			);
		}
	glEnd();

	       ///  BIRD BIRD BIRD BIRD                 BIRD 4                   BIRD BIRD BIRD BIRD

    //GLfloat irdrrr=-0.518f; GLfloat irdrrr4=.801f; GLfloat radius_bird4 =.01f;
int q0;

    GLfloat a08=-0.518f; GLfloat b08=.801f; GLfloat radius08 =.01f;
	glColor3ub(140, 255, 102);
	int triangleAmount08 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi08 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a08, b08); // center of circle
		for(q0= 0; q0 <= triangleAmount08;q0++) {
			glVertex2f(
		            a08+ (radius08 * cos(q0 *  twicePi08 / triangleAmount08)),
			    b08 + (radius08 * sin(q0 * twicePi08 / triangleAmount08))
			);
		}
	glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(140, 255, 102 );
        glVertex2f(-0.6f,0.8f);
        glVertex2f(-0.59f,0.79f);
        glVertex2f(-0.58f,0.78f);
        glVertex2f(-0.54f,0.77f);
        glVertex2f(-0.51f,0.79f);
        glVertex2f(-0.499f,0.8f);
        glEnd();

        glBegin(GL_TRIANGLES);
        glColor3ub(140, 255, 102);
        glVertex2f(-0.525f,0.8f);
        glVertex2f(-0.55f,0.8f);
        glVertex2f(-0.56f,0.84f);
        glEnd();


        glBegin(GL_TRIANGLES);
        glColor3ub(140, 255, 102 );
        glVertex2f(-0.525f,0.8f);
        glVertex2f(-0.556f,0.8f);
        glVertex2f(-0.58f,0.83f);
        glEnd();

     glLoadIdentity();
}
void star()
{
    glPointSize( 2.5 );
    glBegin(GL_POINTS);
    glColor3ub(255, 255, 255);
    glVertex2f(0.8f,0.95f);
    glVertex2f(0.9f,0.9f);
    glVertex2f(0.95f,0.7f);
    glVertex2f(0.8f,0.8f);
    glVertex2f(0.7f,0.9f);
    glVertex2f(0.6f,0.8f);
    glVertex2f(0.5f,0.75f);
    glVertex2f(0.4f,0.9f);
    glVertex2f(0.3f,0.7f);
    glVertex2f(0.25f,0.9f);
    glVertex2f(0.25f,0.7f);
    glVertex2f(0.1f,0.9f);
    glVertex2f(0.15f,0.75f);
    glVertex2f(0.0f,0.8f);
    glVertex2f(-0.7f,0.9f);
    glVertex2f(-0.8f,0.95f);
    glVertex2f(-0.4f,0.8f);
    glVertex2f(-0.8f,0.95f);
    glVertex2f(-0.9f,0.9f);
    glVertex2f(-0.95f,0.7f);
    glVertex2f(-0.8f,0.8f);
    glVertex2f(-0.7f,0.9f);
    glVertex2f(-0.6f,0.8f);
    glVertex2f(-0.5f,0.75f);
    glVertex2f(-0.4f,0.9f);
    glVertex2f(-0.3f,0.7f);
    glVertex2f(-0.25f,0.9f);
    glVertex2f(-0.25f,0.7f);
    glVertex2f(-0.15f,0.75f);
    glVertex2f(-0.1f,0.9f);
    glEnd();

}

void GrassDown()
{
    ///Grass Down
        glTranslatef(0,-0.55,0 );
        glScalef(1.0,.45,0);
        glBegin(GL_QUADS); /// Grass
        glColor3ub(204, 153, 0);
        glVertex2f(1,-.5);
        glVertex2f(-1,-.5);
        glVertex2f(-1,-1);
        glVertex2f(1,-1);
        glEnd();
        glBegin(GL_QUADS); /// Grass2
        glColor3ub(179, 134, 0);
        glVertex2f(1,-.58);
        glVertex2f(-1,-.75);
        glVertex2f(-1,-1);
        glVertex2f(1,-1);
        glEnd();
        glBegin(GL_QUADS); /// Grass3
        glColor3ub(153, 115, 0);
        glVertex2f(1,-.7);
        glVertex2f(-1,-.95);
        glVertex2f(-1,-1);
        glVertex2f(1,-1);
        glEnd();
        glBegin(GL_TRIANGLES); ///grass down
        glColor3ub(204, 153, 0);
        glVertex2f(-.82,-.5);
        glVertex2f(-.8,-.44);
        glVertex2f(-.86,-.5);
        glVertex2f(-.78,-.5);
        glVertex2f(-.76,-.46);
        glVertex2f(-.84,-.5);
        glVertex2f(-.54,-.5);
        glVertex2f(-.52,-.44);
        glVertex2f(-.56,-.5);
        glVertex2f(-.44,-.5);
        glVertex2f(-.48,-.46);
        glVertex2f(-.5,-.5);
        glVertex2f(-.42,-.5);
        glVertex2f(-.46,-.46);
        glVertex2f(-.48,-.5);
        glVertex2f(-.14,-.5);
        glVertex2f(-.14,-.46);
        glVertex2f(-.17,-.5);
        glVertex2f(-.1,-.5);
        glVertex2f(-.09,-.46);
        glVertex2f(-.14,-.5);
        glVertex2f(.16,-.5);
        glVertex2f(.15,-.45);
        glVertex2f(.14,-.5);
        glVertex2f(.2,-.5);
        glVertex2f(.2,-.46);
        glVertex2f(.18,-.5);
        glVertex2f(.78,-.5);
        glVertex2f(.8,-.46);
        glVertex2f(.74,-.5);
        glVertex2f(.9,-.5);
        glVertex2f(.83,-.44);
        glVertex2f(.8,-.5);
        glVertex2f(.94,-.5);
        glVertex2f(.9,-.46);
        glVertex2f(.9,-.5);
        glEnd();
        glLoadIdentity();
}

void GrassDown_Night()
{
    ///Grass Down
        glTranslatef(0,-0.55,0 );
        glScalef(1.0,.45,0);
        glBegin(GL_QUADS); /// Grass
        glColor3ub(0, 77, 0);
        glVertex2f(1,-.5);
        glVertex2f(-1,-.5);
        glVertex2f(-1,-1);
        glVertex2f(1,-1);
        glEnd();
        glBegin(GL_QUADS); /// Grass2
        glColor3ub(38, 115, 77);
        glVertex2f(1,-.58);
        glVertex2f(-1,-.75);
        glVertex2f(-1,-1);
        glVertex2f(1,-1);
        glEnd();
        glBegin(GL_QUADS); /// Grass3
        glColor3ub(0, 77, 0);
        glVertex2f(1,-.7);
        glVertex2f(-1,-.95);
        glVertex2f(-1,-1);
        glVertex2f(1,-1);
        glEnd();
        glBegin(GL_TRIANGLES); ///grass down
        glColor3ub(0, 77, 0);
        glVertex2f(-.82,-.5);
        glVertex2f(-.8,-.44);
        glVertex2f(-.86,-.5);
        glVertex2f(-.78,-.5);
        glVertex2f(-.76,-.46);
        glVertex2f(-.84,-.5);
        glVertex2f(-.54,-.5);
        glVertex2f(-.52,-.44);
        glVertex2f(-.56,-.5);
        glVertex2f(-.44,-.5);
        glVertex2f(-.48,-.46);
        glVertex2f(-.5,-.5);
        glVertex2f(-.42,-.5);
        glVertex2f(-.46,-.46);
        glVertex2f(-.48,-.5);
        glVertex2f(-.14,-.5);
        glVertex2f(-.14,-.46);
        glVertex2f(-.17,-.5);
        glVertex2f(-.1,-.5);
        glVertex2f(-.09,-.46);
        glVertex2f(-.14,-.5);
        glVertex2f(.16,-.5);
        glVertex2f(.15,-.45);
        glVertex2f(.14,-.5);
        glVertex2f(.2,-.5);
        glVertex2f(.2,-.46);
        glVertex2f(.18,-.5);
        glVertex2f(.78,-.5);
        glVertex2f(.8,-.46);
        glVertex2f(.74,-.5);
        glVertex2f(.9,-.5);
        glVertex2f(.83,-.44);
        glVertex2f(.8,-.5);
        glVertex2f(.94,-.5);
        glVertex2f(.9,-.46);
        glVertex2f(.9,-.5);
        glEnd();
        glLoadIdentity();
}
void rain()
{
    glBegin(GL_LINES);
    glColor3ub(255,255,255);
    glVertex2f(1.0,1.0);
    glVertex2f(0.995,0.975);

    glVertex2f(0.980,1.0);
    glVertex2f(0.975,0.975);

    glVertex2f(0.960,1.0);
    glVertex2f(0.955,0.975);

    glVertex2f(0.940,1.0);
    glVertex2f(0.935,0.98);

    glVertex2f(0.920,1.0);
    glVertex2f(0.915,0.98);

    glVertex2f(0.900,1.0);
    glVertex2f(0.895,0.98);

     glVertex2f(0.880,1.0);
    glVertex2f(0.875,0.98);

     glVertex2f(0.860,1.0);
    glVertex2f(0.855,0.98);

     glVertex2f(0.840,1.0);
    glVertex2f(0.835,0.98);

     glVertex2f(0.820,1.0);
    glVertex2f(0.815,0.98);

      glVertex2f(0.800,1.0);
    glVertex2f(0.795,0.98);

     glVertex2f(0.780,1.0);
    glVertex2f(0.775,0.98);

     glVertex2f(0.760,1.0);
    glVertex2f(0.755,0.98);

     glVertex2f(0.740,1.0);
    glVertex2f(0.735,0.98);

     glVertex2f(0.720,1.0);
    glVertex2f(0.715,0.98);

     glVertex2f(0.700,1.0);
    glVertex2f(0.695,0.98);

     glVertex2f(0.680,1.0);
    glVertex2f(0.675,0.98);

     glVertex2f(0.660,1.0);
    glVertex2f(0.655,0.98);

     glVertex2f(0.640,1.0);
    glVertex2f(0.635,0.98);

     glVertex2f(0.620,1.0);
    glVertex2f(0.615,0.98);

     glVertex2f(0.600,1.0);
    glVertex2f(0.595,0.98);

     glVertex2f(0.580,1.0);
    glVertex2f(0.575,0.98);

     glVertex2f(0.560,1.0);
    glVertex2f(0.555,0.98);

     glVertex2f(0.540,1.0);
    glVertex2f(0.535,0.98);

     glVertex2f(0.520,1.0);
    glVertex2f(0.515,0.98);

     glVertex2f(0.500,1.0);
    glVertex2f(0.495,0.98);

     glVertex2f(0.480,1.0);
    glVertex2f(0.475,0.98);

     glVertex2f(0.460,1.0);
    glVertex2f(0.455,0.98);

     glVertex2f(0.440,1.0);
    glVertex2f(0.435,0.98);

     glVertex2f(0.420,1.0);
    glVertex2f(0.415,0.98);

     glVertex2f(0.400,1.0);
    glVertex2f(0.395,0.98);

     glVertex2f(0.380,1.0);
    glVertex2f(0.375,0.98);

     glVertex2f(0.360,1.0);
    glVertex2f(0.355,0.98);

     glVertex2f(0.340,1.0);
    glVertex2f(0.335,0.98);

     glVertex2f(0.320,1.0);
    glVertex2f(0.315,0.98);

     glVertex2f(0.300,1.0);
    glVertex2f(0.295,0.98);

     glVertex2f(0.280,1.0);
    glVertex2f(0.275,0.98);

     glVertex2f(0.260,1.0);
    glVertex2f(0.255,0.98);

     glVertex2f(0.240,1.0);
    glVertex2f(0.235,0.98);

     glVertex2f(0.220,1.0);
    glVertex2f(0.215,0.98);

     glVertex2f(0.200,1.0);
    glVertex2f(0.195,0.98);

     glVertex2f(0.180,1.0);
    glVertex2f(0.175,0.98);

     glVertex2f(0.160,1.0);
    glVertex2f(0.155,0.98);

     glVertex2f(0.140,1.0);
    glVertex2f(0.135,0.98);

     glVertex2f(0.120,1.0);
    glVertex2f(0.115,0.98);

     glVertex2f(0.100,1.0);
    glVertex2f(0.095,0.98);

     glVertex2f(0.080,1.0);
    glVertex2f(0.075,0.98);

     glVertex2f(0.060,1.0);
    glVertex2f(0.055,0.98);

     glVertex2f(0.040,1.0);
    glVertex2f(0.035,0.98);

     glVertex2f(0.020,1.0);
    glVertex2f(0.015,0.98);

    glVertex2f(0.000,1.0);
    glVertex2f(-0.005,0.98);

    glVertex2f(-0.020,1.0);
    glVertex2f(-0.025,0.98);

    glVertex2f(-0.040,1.0);
    glVertex2f(-0.045,0.98);

    glVertex2f(-0.060,1.0);
    glVertex2f(-0.065,0.98);

    glVertex2f(-0.080,1.0);
    glVertex2f(-0.085,0.98);

    glVertex2f(-0.100,1.0);
    glVertex2f(-0.105,0.98);

    glVertex2f(-0.120,1.0);
    glVertex2f(-0.125,0.98);

    glVertex2f(-0.140,1.0);
    glVertex2f(-0.145,0.98);

    glVertex2f(-0.160,1.0);
    glVertex2f(-0.165,0.98);

    glVertex2f(-0.180,1.0);
    glVertex2f(-0.185,0.98);

    glVertex2f(-0.200,1.0);
    glVertex2f(-0.205,0.98);

    glVertex2f(-0.220,1.0);
    glVertex2f(-0.225,0.98);

    glVertex2f(-0.240,1.0);
    glVertex2f(-0.245,0.98);

    glVertex2f(-0.260,1.0);
    glVertex2f(-0.265,0.98);

    glVertex2f(-0.280,1.0);
    glVertex2f(-0.285,0.98);

    glVertex2f(-0.300,1.0);
    glVertex2f(-0.305,0.98);

    glVertex2f(-0.320,1.0);
    glVertex2f(-0.325,0.98);

    glVertex2f(-0.340,1.0);
    glVertex2f(-0.345,0.98);

    glVertex2f(-0.360,1.0);
    glVertex2f(-0.365,0.98);

    glVertex2f(-0.380,1.0);
    glVertex2f(-0.385,0.98);

    glVertex2f(-0.400,1.0);
    glVertex2f(-0.405,0.98);

    glVertex2f(-0.420,1.0);
    glVertex2f(-0.425,0.98);

    glVertex2f(-0.440,1.0);
    glVertex2f(-0.445,0.98);

    glVertex2f(-0.460,1.0);
    glVertex2f(-0.465,0.98);

    glVertex2f(-0.480,1.0);
    glVertex2f(-0.485,0.98);

    glVertex2f(-0.500,1.0);
    glVertex2f(-0.505,0.98);

    glVertex2f(-0.520,1.0);
    glVertex2f(-0.525,0.98);

    glVertex2f(-0.540,1.0);
    glVertex2f(-0.545,0.98);

    glVertex2f(-0.560,1.0);
    glVertex2f(-0.565,0.98);

    glVertex2f(-0.580,1.0);
    glVertex2f(-0.585,0.98);

    glVertex2f(-0.600,1.0);
    glVertex2f(-0.605,0.98);

    glVertex2f(-0.620,1.0);
    glVertex2f(-0.625,0.98);

    glVertex2f(-0.640,1.0);
    glVertex2f(-0.645,0.98);

    glVertex2f(-0.660,1.0);
    glVertex2f(-0.665,0.98);

    glVertex2f(-0.680,1.0);
    glVertex2f(-0.685,0.98);

    glVertex2f(-0.700,1.0);
    glVertex2f(-0.705,0.98);

    glVertex2f(-0.720,1.0);
    glVertex2f(-0.725,0.98);

    glVertex2f(-0.740,1.0);
    glVertex2f(-0.745,0.98);

    glVertex2f(-0.760,1.0);
    glVertex2f(-0.765,0.98);

    glVertex2f(-0.780,1.0);
    glVertex2f(-0.785,0.98);

    glVertex2f(-0.800,1.0);
    glVertex2f(-0.805,0.98);

    glVertex2f(-0.820,1.0);
    glVertex2f(-0.825,0.98);

    glVertex2f(-0.840,1.0);
    glVertex2f(-0.845,0.98);

    glVertex2f(-0.860,1.0);
    glVertex2f(-0.865,0.98);

    glVertex2f(-0.880,1.0);
    glVertex2f(-0.885,0.98);

    glVertex2f(-0.900,1.0);
    glVertex2f(-0.905,0.98);

    glVertex2f(-0.920,1.0);
    glVertex2f(-0.925,0.98);

    glVertex2f(-0.940,1.0);
    glVertex2f(-0.945,0.98);

    glVertex2f(-0.960,1.0);
    glVertex2f(-0.965,0.98);

    glVertex2f(-0.980,1.0);
    glVertex2f(-0.985,0.98);

    glEnd();
    //glLineWidth(0.4);

}


void fullrain()
{
    glTranslatef(0.0,-0.15,0.0);
    rain();


    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

    glTranslatef(0.0,-0.15,0.0);
    rain();

}

void Building()
{
    /// D building /// ///


glTranslatef(0.35,0.3,0 );
        glScalef(.5,.5,0);
    //siri
    glColor3ub(209,209,224);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.310*3.0-.75f);
    glVertex2f(.333*2.4-.50f,.295*3.0-.75f);
    glVertex2f(.603*2.4-.50f,.295*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.310*3.0-.75f);

    glColor3ub(92,92,138);

    glBegin(GL_QUADS);
    glVertex2f(.333*2.4-.50f,.295*3.0-.75f);
    glVertex2f(.336*2.4-.50f,.290*3.0-.75f);
    glVertex2f(.606*2.4-.50f,.290*3.0-.75f);
    glVertex2f(.603*2.4-.50f,.295*3.0-.75f);

    glColor3ub(209,209,224);

    glBegin(GL_QUADS);
    glVertex2f(.336*2.4-.50f,.290*3.0-.75f);
    glVertex2f(.339*2.4-.50f,.285*3.0-.75f);
    glVertex2f(.609*2.4-.50f,.285*3.0-.75f);
    glVertex2f(.606*2.4-.50f,.290*3.0-.75f);

    glColor3ub(92,92,138);

    glBegin(GL_QUADS);
    glVertex2f(.339*2.4-.50f,.285*3.0-.75f);
    glVertex2f(.342*2.4-.50f,.280*3.0-.75f);
    glVertex2f(.612*2.4-.50f,.280*3.0-.75f);
    glVertex2f(.609*2.4-.50f,.285*3.0-.75f);

    glColor3ub(209,209,224);

    glBegin(GL_QUADS);
    glVertex2f(.342*2.4-.50f,.280*3.0-.75f);
    glVertex2f(.345*2.4-.50f,.275*3.0-.75f);
    glVertex2f(.615*2.4-.50f,.275*3.0-.75f);
    glVertex2f(.612*2.4-.50f,.280*3.0-.75f);

    glColor3ub(92,92,138);

    glBegin(GL_QUADS);
    glVertex2f(.345*2.4-.50f,.275*3.0-.75f);
    glVertex2f(.348*2.4-.50f,.270*3.0-.75f);
    glVertex2f(.618*2.4-.50f,.270*3.0-.75f);
    glVertex2f(.615*2.4-.50f,.275*3.0-.75f);

    glColor3ub(92,92,138);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.310*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.270*3.0-.75f);
    glVertex2f(.348*2.4-.50f,.270*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.310*3.0-.75f);





    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.310*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.300*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.300*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.310*3.0-.75f);

    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.325*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.310*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.310*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.325*3.0-.75f);


    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.335*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.320*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.320*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.335*3.0-.75f);

    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.350*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.330*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.330*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.350*3.0-.75f);



    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.360*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.340*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.340*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.360*3.0-.75f);


    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.375*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.350*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.350*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.375*3.0-.75f);


    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.385*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.360*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.360*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.385*3.0-.75f);

    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.400*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.370*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.370*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.400*3.0-.75f);

    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.410*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.380*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.380*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.410*3.0-.75f);

    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.425*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.390*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.390*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.425*3.0-.75f);


    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.435*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.400*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.400*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.435*3.0-.75f);

    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.450*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.410*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.410*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.450*3.0-.75f);

    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.460*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.420*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.420*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.460*3.0-.75f);

    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.470*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.430*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.430*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.470*3.0-.75f);

    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.480*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.440*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.440*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.480*3.0-.75f);

    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.495*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.450*3.0-.75f);
    glVertex2f(.590*2.4-.50f,.450*3.0-.75f);
    glVertex2f(.590*2.4-.50f,.495*3.0-.75f);

    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.505*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.460*3.0-.75f);
    glVertex2f(.590*2.4-.50f,.460*3.0-.75f);
    glVertex2f(.590*2.4-.50f,.505*3.0-.75f);
    //TOP
    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.330*2.4-.50f,.480*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.470*3.0-.75f);
    glVertex2f(.590*2.4-.50f,.470*3.0-.75f);
    glVertex2f(.590*2.4-.50f,.480*3.0-.75f);

    //r8 top deyal
    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.590*2.4-.50f,.505*3.0-.75f);
    glVertex2f(.590*2.4-.50f,.480*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.480*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.505*3.0-.75f);



    //lft deyal
    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.320*2.4-.50f,.520*3.0-.75f);
    glVertex2f(.320*2.4-.50f,.300*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.300*3.0-.75f);
    glVertex2f(.330*2.4-.50f,.520*3.0-.75f);


    //r8 7 tala porjonto deyal
    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.600*2.4-.50f,.450*3.0-.75f);
    glVertex2f(.600*2.4-.50f,.300*3.0-.75f);
    glVertex2f(.610*2.4-.50f,.300*3.0-.75f);
    glVertex2f(.610*2.4-.50f,.450*3.0-.75f);

    //lftt fst glass deyal
    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.300*2.4-.50f,.440*3.0-.75f);
    glVertex2f(.300*2.4-.50f,.320*3.0-.75f);
    glVertex2f(.320*2.4-.50f,.300*3.0-.75f);
    glVertex2f(.320*2.4-.50f,.445*3.0-.75f);

    //lst fst glass deyalrr uporer delay
    glColor3ub(200,218,218);

    glBegin(GL_QUADS);
    glVertex2f(.300*2.4-.50f,.520*3.0-.75f);
    glVertex2f(.300*2.4-.50f,.440*3.0-.75f);
    glVertex2f(.320*2.4-.50f,.445*3.0-.75f);
    glVertex2f(.320*2.4-.50f,.520*3.0-.75f);

    //lft glass deyal
    glColor3ub(0,143,230);

    glBegin(GL_QUADS);
    glVertex2f(.280*2.4-.50f,.520*3.0-.75f);
    glVertex2f(.280*2.4-.50f,.325*3.0-.75f);
    glVertex2f(.300*2.4-.50f,.320*3.0-.75f);
    glVertex2f(.300*2.4-.50f,.520*3.0-.75f);

glEnd();
 glLoadIdentity();
///End building ///
}

void WindMill()
{
    ///Wind Mill
	    glBegin(GL_QUADS); ///Black
        glColor3ub(0, 0, 0);
        glVertex2f(-.0705,.44);
        glVertex2f(-.1285,.44);
        glVertex2f(-.1285,.41);
        glVertex2f(-.0705,.41);

        glVertex2f(-.0705,.41);
        glVertex2f(-.1285,.41);
        glVertex2f(-.171,.2);
        glVertex2f(-.0291,.2);

        glVertex2f(-.04,.2);
        glVertex2f(-.16,.2);
        glVertex2f(-.18,.12);
        glVertex2f(-.02,.12);
        glEnd();

        glBegin(GL_QUADS); ///white
        glColor3ub(230, 255, 255);
        glVertex2f(-.08,.4);
        glVertex2f(-.12,.4);
        glVertex2f(-.16,.22);
        glVertex2f(-.04,.22);

        glVertex2f(-.05,.205);
        glVertex2f(-.15,.205);
        glVertex2f(-.17,.13);
        glVertex2f(-.03,.13);
        glEnd();

        glBegin(GL_TRIANGLES); ///up
        glColor3ub(0,0,0);
        glVertex2f(-.06,.41);
        glVertex2f(-.1,.45);
        glVertex2f(-.14,.41);
        glEnd();
        glBegin(GL_TRIANGLES); ///up
        glColor3ub(0, 0, 0);
        glVertex2f(-.0705,.44);
        glVertex2f(-.1,.51);
        glVertex2f(-.1285,.44);
        glEnd();

        glBegin(GL_QUADS); ///door
        glColor3ub(51, 102, 153);
        glVertex2f(-.08,.195);
        glVertex2f(-.12,.195);
        glVertex2f(-.12,.13);
        glVertex2f(-.08,.13);
        glEnd();

        glBegin(GL_LINES);  ///door Line
        glColor3ub(0, 0, 0);
        glVertex2f(-.1,.195);
        glVertex2f(-.1,.13);
        glEnd();

        glBegin(GL_QUADS); ///mill Window
        glColor3ub(26, 26, 26);
        glVertex2f(-.08,.29);
        glVertex2f(-.12,.29);
        glVertex2f(-.12,.24);
        glVertex2f(-.08,.24);
        glEnd();

        glBegin(GL_LINES);  /// window Line
        glColor3ub(255, 255, 153);
        glVertex2f(-.1,.29);
        glVertex2f(-.1,.24);
        glVertex2f(-.08,.265);
        glVertex2f(-.12,.265);
        glEnd();

        glTranslatef(0,.075,0 ); ///copy Window
        glBegin(GL_QUADS); ///mill Window
        glColor3ub(26, 26, 26);
        glVertex2f(-.08,.29);
        glVertex2f(-.12,.29);
        glVertex2f(-.12,.24);
        glVertex2f(-.08,.24);
        glEnd();

        glBegin(GL_LINES);  /// window Line
        glColor3ub(255, 255, 153);
        glVertex2f(-.1,.29);
        glVertex2f(-.1,.24);
        glVertex2f(-.08,.265);
        glVertex2f(-.12,.265);
        glEnd();


        ///Fan
        glTranslatef(-.1,.37,0);
        glScalef(.12,.12,0);
        int i;

    GLfloat x=.0f; GLfloat y=.0f; GLfloat radius =.2f;
    int triangleAmount = 20;
    GLfloat twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 78, 162);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
        glVertex2f(
                x + (radius * cos(i *  twicePi / triangleAmount)),
            y + (radius * sin(i * twicePi / triangleAmount))
        );
    }
	glEnd();

        glPushMatrix();
        glRotatef(t,0.0,0.0,0.1);

	glBegin(GL_QUADS);
	glColor3ub(0, 78, 162);
	glVertex2f(-.05f,.1f);
	glVertex2f(-.1f,.05f);
	glVertex2f(-.7f,.55);
	glVertex2f(-.55f,.7f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(0, 78, 162);
	glVertex2f(-.05f,-.1f);
	glVertex2f(-.1f,-.05f);
	glVertex2f(-.7f,-.55);
	glVertex2f(-.55f,-.7f);
	glEnd();


    glBegin(GL_QUADS);
	glColor3ub(0, 78, 162);
	glVertex2f(.05f,-.1f);
	glVertex2f(.1f,-.05f);
	glVertex2f(.7f,-.55);
	glVertex2f(.55f,-.7f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(0, 78, 162);
	glVertex2f(.05f,.1f);
	glVertex2f(.1f,.05f);
	glVertex2f(.7f,.55);
	glVertex2f(.55f,.7f);
	glEnd();

	    glPopMatrix();
        t+=0.2f;

	x=.0f;  y=.0f;  radius =.15f;
    triangleAmount = 20;
    twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,255,255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
        glVertex2f(
                x + (radius * cos(i *  twicePi / triangleAmount)),
            y + (radius * sin(i * twicePi / triangleAmount))
        );
    }
	glEnd();

        glLoadIdentity();
}




void drawCircle(GLfloat x,GLfloat y,GLfloat radius)
{
	int i;
	int lineAmount = 100;
	GLfloat twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
	glVertex2f(x,y);
	//glColor3ub(255, 0, 191);
		for(i = 0; i <= lineAmount;i++)
        {
			glVertex2f(x + (radius * cos(i *  twicePi / lineAmount)),y + (radius* sin(i * twicePi / lineAmount)));

		}
	glEnd();
}

void drawQuad(GLfloat x0, GLfloat y0, GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2, GLfloat x3, GLfloat y3)
{
    glBegin(GL_QUADS);

    glVertex2f(x0,y0);

    glVertex2f(x1,y1);

    glVertex2f(x2,y2);

    glVertex2f(x3,y3);

    glEnd();
}
void drawTriangle(GLfloat x0, GLfloat y0, GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2)
{
    glBegin(GL_TRIANGLES);

    glVertex2f(x0,y0);

    glVertex2f(x1,y1);

    glVertex2f(x2,y2);

    glEnd();
}

void Idle()
{
    glutPostRedisplay();
}

/// //////////////////////////////// /////////////////////////// ////////////////////

void rainAnimation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(positionRain, positionRain, 0.0f);
    fullrain();
    glPopMatrix();
    glLoadIdentity();
}

void snowAnimation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(snowPosition, snowPosition, 0.0f);
    snow();
    glPopMatrix();
    glLoadIdentity();
}

void SunAnimation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(0.0f, positionSun, 0.0f);
    Sun();
    glPopMatrix();
    glLoadIdentity();
}

void MoonAnimation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(0.0f, positionMoon, 0.0f);
    Moon();
    glPopMatrix();
    glLoadIdentity();
}

void cloud1Animation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(positionCloud1, 0.0f, 0.0f);
    Cloud1();
    glPopMatrix();
    glLoadIdentity();
}
void cloud4Animation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(positionCloud1, 0.0f, 0.0f);
    Cloud4();
    glPopMatrix();
    glLoadIdentity();
}

void cloud2Animation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(positionCloud2, 0.0f, 0.0f);
    Cloud2();
    glPopMatrix();
    glLoadIdentity();
}
void cloud3Animation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(positionCloud2, 0.0f, 0.0f);
    Cloud3();
    glPopMatrix();
    glLoadIdentity();
}

void HelecopterAnimation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(positionCloud2, 0.0f, 0.0f);
    Helecopter();
    glPopMatrix();
    glLoadIdentity();
}

void standingBoatAnimation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(0.0f, positionStandinfBoat, 0.0f);
    Boat();
    glPopMatrix();
    glLoadIdentity();
}

void standingBoatAnimation2()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(0.0f, positionStandinfBoat, 0.0f);
    Boat();
    glPopMatrix();
    glLoadIdentity();
}

void birdAnimation()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(positionBird, 0.0f, 0.0f);
    Bird();
    glPopMatrix();
    glLoadIdentity();
}
void CarAnimation1()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(positionCar, 0.0f, 0.0f);
    Car1();
    glPopMatrix();
    glLoadIdentity();
}

void CarAnimation2()
{
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(positionCar2, 0.0f, 0.0f);
    Car2();
    glPopMatrix();
    glLoadIdentity();
}

void dayRainDisplay(int x)
{
    glutDisplayFunc(dayRain);
}

void dayRain()
{
    glClearColor(1.0,1.0,1.0,1.0);
    glClear(GL_COLOR_BUFFER_BIT);

    NightSky();
    cloud1Animation();
    cloud2Animation();
    Grass();
    River();
    standingBoatAnimation();
    GrassDown();
    Tree();
    Building();
    National_Assembly();
    Road();
    CarAnimation1();
    CarAnimation2();
    Lamp();

    rainAnimation();
    glutTimerFunc(10000, nightDispaly, 0);

    glFlush();
}

void dayRain1()
{
    //Sky();
    NightSky();
    cloud1Animation();
    cloud2Animation();
    Grass();
    River();
    standingBoatAnimation();
    GrassDown();
    Tree();
    Building();
    National_Assembly();
    Road();
    CarAnimation1();
    CarAnimation2();
    Lamp();
    rainAnimation();
    glutTimerFunc(10000, dayRainDisplay, 0);
    glFlush();
}

void dayDisplay(int x)
{
    glutDisplayFunc(Day);
}
void Day()
{
    glClearColor(1.0,1.0,1.0,1.0);
    glClear(GL_COLOR_BUFFER_BIT);

    Sky();
    SunAnimation();
    cloud1Animation();
    cloud2Animation();
    cloud3Animation();
    cloud4Animation();
    Grass();
    River();
    standingBoatAnimation();
    GrassDown();
    Tree();
    Building();
    National_Assembly();
    Road();
    CarAnimation1();
    CarAnimation2();
    Lamp();
    HelecopterAnimation();
    birdAnimation();
    //WindMill();

    glutTimerFunc(10000, dayRainDisplay, 0);
    glFlush();

}

void Day1()
{
    Sky();
    SunAnimation();
    cloud1Animation();
    cloud2Animation();
    cloud3Animation();
    cloud4Animation();
    Grass();
    River();
    standingBoatAnimation();
    GrassDown();
    Tree();
    Building();
    National_Assembly();
    Road();
    CarAnimation1();
    CarAnimation2();
    Lamp();
    HelecopterAnimation();
    birdAnimation();
     glutTimerFunc(10000, dayDisplay, 0);

    glFlush();

}

void nightDispaly(int x)
{
    glutDisplayFunc(Night);
}
void Night()
{
    glClearColor(1.0,1.0,1.0,1.0);
    //glClear(GL_COLOR_BUFFER_BIT);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    NightSky();
    MoonAnimation();
    Grass_Night();
    GrassDown_Night();
    Road_Night();
    Lamp();
    River_Night();
    cloud1Animation();
    cloud2Animation();
    cloud3Animation();
    cloud4Animation();
    Building();
    National_Assembly_Night();
    Flower();
    Tree();
    star();
    CarAnimation1();
    CarAnimation2();
    HelecopterAnimation();
    standingBoatAnimation();
    birdAnimation();

    glutTimerFunc(10000, nightRainDispaly, 0);

    glFlush();
}

void Night1()
{
    NightSky();
    MoonAnimation();
    Grass_Night();
    GrassDown_Night();
    Road_Night();
    Lamp();
    River_Night();
    cloud1Animation();
    cloud2Animation();
    cloud3Animation();
    cloud4Animation();
    Building();
    National_Assembly_Night();
    Flower();
    Tree();
    star();
    CarAnimation1();
    CarAnimation2();
    HelecopterAnimation();
    standingBoatAnimation();
    birdAnimation();
    glutTimerFunc(10000, nightDispaly, 0);
    glFlush();
}

void nightRainDispaly(int x)
{
    glutDisplayFunc(nightRain);
}

void nightRain()
{
    glClearColor(1.0,1.0,1.0,1.0);
    //glClear(GL_COLOR_BUFFER_BIT);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    NightSky();
    Grass_Night();
    GrassDown_Night();
    Road_Night();
    Lamp();
    River_Night();
    Building();
    National_Assembly_Night();
    Tree();
    CarAnimation1();
    CarAnimation2();
    HelecopterAnimation();
    standingBoatAnimation();
    snowAnimation();
    snow();
    glutTimerFunc(10000, dayDisplay, 0);

    glFlush();
}
void nightRain1()
{
    NightSky();
    Grass_Night();
    GrassDown_Night();
    Road_Night();
    Lamp();
    River_Night();
    Building();
    National_Assembly_Night();
    Tree();
    CarAnimation1();
    CarAnimation2();
    HelecopterAnimation();
    standingBoatAnimation();
    snowAnimation();
    snow();
    glFlush();
}

void display()
{
    Day();
    glFlush();
}



void handleKeypress(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 'r':
            glutDisplayFunc(dayRain1);
        break;

        case 's':
            glutDisplayFunc(nightRain1);
        break;

        case 'n':
           glutDisplayFunc(Night1);
        break;

        case 'a':
            glutDisplayFunc(Day1);
        break;

        case 'd':
           glutDisplayFunc(display);
        break;
    }
    glutPostRedisplay();
}

void sound()
{

    //PlaySound("a.wav", NULL, SND_ASYNC|SND_FILENAME);
    PlaySound("a.wav", NULL,SND_ASYNC|SND_FILENAME|SND_LOOP);
    //sndPlaySound("a.wav", NULL,SND_ASYNC);

}

void init()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

int main(int argc,char ** argv){

    glutInit(&argc,argv);
    glutInitWindowSize(1200,600);
    glutInitWindowPosition(100,50);
    glutCreateWindow("Seasonal Scene");
    init();
    glutDisplayFunc(display);
    glutIdleFunc(Idle);


    glutTimerFunc(100, updateRain, 0);
    glutTimerFunc(100, updateBoat, 0);
    glutTimerFunc(100, updateCloud1, 0);
    glutTimerFunc(100, updateCloud2, 0);
    glutTimerFunc(100, updateBird, 0);
    glutTimerFunc(100, updateCar, 0);
    glutTimerFunc(100, updateCar2, 0);
    glutTimerFunc(100, updateStandingBoat, 0);
    glutTimerFunc(100, updateSun, 0);
    glutTimerFunc(100, updateMoon, 0);
    glutTimerFunc(300, update11, 0);

//    glutKeyboardFunc(keyboard);
    glutKeyboardFunc(handleKeypress);
    sound();
    glutMainLoop();
    return 0;
}
